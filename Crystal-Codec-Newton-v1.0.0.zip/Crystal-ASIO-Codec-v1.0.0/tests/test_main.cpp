/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       tests/test_main.cpp
 *  Purpose:    Unit tests: ring wraparound/desync, codec, conversion, config, telemetry
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/audio_ring_buffer.hpp"
#include "crystal/config.hpp"
#include "crystal/opus_codec.hpp"
#include "crystal/rt_guard.hpp"
#include "crystal/sample_convert.hpp"
#include "crystal/telemetry.hpp"

#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

namespace {

int failures = 0;
#define CHECK(x) do { \
    if (!(x)) { \
        std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << " " #x "\n"; \
        ++failures; \
    } \
} while (false)

void test_ring() {
    crystal::AudioRingBuffer ring(8, 2);
    std::array<float, 16> in{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}, out{};
    CHECK(ring.write_frames(in.data(), 4) == 4);
    CHECK(ring.read_frames(out.data(), 3) == 3);
    CHECK(ring.write_frames(in.data() + 6, 5) == 5);
    std::array<float, 12> got{};
    CHECK(ring.read_frames(got.data(), 6) == 6);
    CHECK(got[0] == 6 && got[1] == 7 && got[2] == 6 && got[3] == 7 &&
          got[10] == 14 && got[11] == 15);
    CHECK(ring.available_frames() == 0);
}

void test_ring_desync_flag() {
    crystal::AudioRingBuffer ring(8, 1);
    CHECK(!ring.desync_detected());
    std::array<float, 8> in{0,1,2,3,4,5,6,7}, out{};
    CHECK(ring.write_frames(in.data(), 8) == 8);
    CHECK(!ring.desync_detected());
    CHECK(ring.read_frames(out.data(), 8) == 8);
    CHECK(!ring.desync_detected());
}

void test_ring_clear_refills_silence() {
    crystal::AudioRingBuffer ring(8, 1);
    std::array<float, 8> in{1,2,3,4,5,6,7,8}, out{};
    CHECK(ring.write_frames(in.data(), 8) == 8);
    ring.clear_quiescent();
    CHECK(ring.write_frames(in.data(), 2) == 2);
    CHECK(ring.read_frames(out.data(), 2) == 2);
    CHECK(out[0] == 1.0F && out[1] == 2.0F);
}

void test_convert() {
    std::array<std::int16_t, 4> pcm{-32768, -1, 0, 32767};
    std::array<float, 4> f{};
    CHECK(crystal::to_float(pcm.data(), f.data(), f.size(),
                            crystal::SampleFormat::Pcm16));
    CHECK(f[0] == -1.0F && f[2] == 0.0F && f[3] > 0.99F);

    std::array<std::uint8_t, 3> p24{0x00, 0x00, 0x80};
    float x = 0;
    CHECK(crystal::to_float(p24.data(), &x, 1, crystal::SampleFormat::Pcm24));
    CHECK(x == -1.0F);

    // Round-trip PCM16
    std::array<std::int16_t, 4> back{};
    CHECK(crystal::from_float(f.data(), back.data(), f.size(),
                              crystal::SampleFormat::Pcm16));
    CHECK(back[0] == -32767 && back[3] == 32766);
}

void test_config() {
    crystal::Config c{};
    std::string e;
    CHECK(crystal::validate_config(c, e));
    c.asio_buffer_frames = 1;
    CHECK(!crystal::validate_config(c, e));
}

void test_telemetry() {
    crystal::Telemetry t;
    t.record_underrun();
    t.record_switch(64);
    t.record_desync();
    auto s = t.snapshot();
    CHECK(s.underruns == 1 && s.buffer_switches == 1 && s.frames == 64 && s.desyncs == 1);
    CHECK(t.to_json().find("\"frames\":64") != std::string::npos);
    CHECK(t.to_json().find("\"desyncs\":1") != std::string::npos);
}

void test_opus_unavailable_is_explicit() {
    crystal::OpusConfig c{};
    std::string e;
#ifndef CRYSTAL_HAVE_OPUS
    CHECK(crystal::OpusCodec::create(c, e) == nullptr);
    CHECK(!e.empty());
#endif
}

void test_opus_decode_rejects_undersized() {
    crystal::OpusConfig c{};
    std::string e;
    auto codec = crystal::OpusCodec::create(c, e);
#ifdef CRYSTAL_HAVE_OPUS
    if (codec) {
        float pcm[2] = {0, 0};
        CHECK(codec->decode(nullptr, 0, pcm, 1) == -1);
        CHECK(codec->decode(nullptr, -1, pcm,
              static_cast<int>(codec->frame_size())) == -1);
        CHECK(codec->decode(nullptr, 1 << 20, pcm,
              static_cast<int>(codec->frame_size())) == -1);
        CHECK(codec->decode(nullptr, 10, pcm,
              static_cast<int>(codec->frame_size())) == -1);
    }
#else
    CHECK(codec == nullptr);
    CHECK(!e.empty());
#endif
}

void test_rt_denormal_guard_scope() {
    const bool before = crystal::RtDenormalGuard::current_thread_has_flush();
    {
        crystal::RtDenormalGuard g;
#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__) || defined(_M_IX86) \
    || defined(__aarch64__)
        CHECK(crystal::RtDenormalGuard::current_thread_has_flush());
#endif
    }
    CHECK(crystal::RtDenormalGuard::current_thread_has_flush() == before);
}

} // namespace

int main() {
    test_ring();
    test_ring_desync_flag();
    test_ring_clear_refills_silence();
    test_convert();
    test_config();
    test_telemetry();
    test_opus_unavailable_is_explicit();
    test_opus_decode_rejects_undersized();
    test_rt_denormal_guard_scope();

    if (failures) {
        std::cerr << failures << " test(s) failed\n";
        return EXIT_FAILURE;
    }
    std::cout << "Crystal ASIO Codec core tests passed\n";
    return EXIT_SUCCESS;
}
