# Build status — Crystal Codec - Newton (Crystal Cheairs / Rev. Cheairs / Crystal City)

**Crystal Codec - Newton** | Crystal City | Developed by Lewis J. Seals Jr. (Therealla) - ljrseals-dev

Environment verified in this session: Linux, GCC, CMake, Release
configuration, warnings-as-errors enabled.

- Configure: PASS
- Compile: PASS
- CTest: PASS (1 test executable containing ring wraparound, ring desync
  flag, ring clear refill, sample conversion, config validation, telemetry,
  explicit missing-libopus behavior, Opus decode bounds rejection, and
  denormal guard scope)
- Hardware / DAW / Windows MSVC / Clang / 24-hour tests: NOT RUN
- ASIO driver + WASAPI backend: NOT IMPLEMENTED
- libopus-enabled build: NOT RUN by default; default build does not pretend
  Opus is active
- AVX2 accelerated copies: NOT IMPLEMENTED

This is a passing portable core build, not a validated ASIO driver release.
The build must not be marketed as production-ready until the missing platform
integration and the master brief's hardware acceptance criteria are completed.

## Post-review hardening (this session)

- Opus decode() now rejects undersized output buffers, negative packet
  sizes, oversized packets, and null-packet-with-nonzero-length before
  libopus is invoked. This closes the failure mode of CVE-2026-45515
  (Android A2DP Opus) at the API boundary.
- Opus encode() now rejects negative and oversized packet capacities.
- AudioRingBuffer now reports producer/consumer desync via an explicit
  flag instead of silently clamping forever. The clamp remains for
  safety; the tell is now visible.
- AudioRingBuffer::clear_quiescent() asserts in debug builds that the
  producer and consumer are stopped, and now zero-fills the storage.
- Added RtDenormalGuard (FTZ/DAZ on x86, FPCR.FZ on ARM64). Construct
  one per audio callback, not per inner loop.
- Telemetry gained a desync counter and is explicitly documented as
  control-thread-only for to_json().
