# Architecture and release status

**Crystal Codec — Crystal Cheairs and Rev. Cheairs — for Crystal City**

**Crystal Codec - Newton** | Crystal City | Developed by Lewis J. Seals Jr. (Therealla) - ljrseals-dev

## Intended pipeline

```
WASAPI capture -> input SPSC ring -> worker (Opus or passthrough)
-> output SPSC ring -> ASIO host buffers / buffer switch -> DAW
-> output routing -> WASAPI render
```

The pipeline is the target architecture, not yet wired end-to-end in this
core package. ASIO host buffer ownership and callback sequencing must be
implemented against the official SDK.

## Threading contracts

- Ring producer and consumer are single-owner roles.
- Construct/allocate rings and codec state before streaming.
- Codec API calls are worker-thread operations only.
- Config file I/O and JSON telemetry formatting are control-thread operations only.
- Construct `RtDenormalGuard` once per audio callback at the top of the callback.
- Do not invoke throwing constructors or `clear_quiescent` during streaming.
- `std::atomic<uint64_t>` lock freedom is platform-dependent; verify
  `is_lock_free()` on supported targets if strict lock-free operation is a
  release requirement.

## Desync detection

`AudioRingBuffer` uses monotonic 64-bit counters. If the producer/consumer
ever disagree by more than capacity, the ring clamps and sets a desync flag.
This is the "rumble" — a fault that would otherwise be silent. Poll
`desync_detected()` from the control thread and record it via
`Telemetry::record_desync()`.

## Denormal handling

Filter tails and converter output near zero can produce subnormal floats,
which cost 10–100x on some microarchitectures. `RtDenormalGuard` sets FTZ/DAZ
on x86 and FPCR.FZ on ARM64 for the duration of the audio callback. This is
the "no frost" property: the slow path never accumulates.

## Known gaps

1. No actual ASIO driver or `bufferSwitch()` implementation.
2. No WASAPI backend or COM threads.
3. No worker context, event wakeup, MMCSS, or shutdown coordinator.
4. No measured physical loopback latency.
5. No hardware/DAW/24-hour acceptance evidence.
6. AVX2 acceleration is not implemented yet; the option only sets compilation
   flags and must not be presented as SIMD acceleration.
