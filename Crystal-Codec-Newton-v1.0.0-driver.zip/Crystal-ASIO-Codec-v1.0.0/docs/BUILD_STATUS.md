# Build status — Crystal Codec - Newton

**Crystal Codec - Newton** | Crystal City | Developed by Lewis J. Seals Jr. (Therealla) - ljrseals-dev

## Verified in this environment (Linux, GCC, -Wall -Wextra -Wpedantic -Werror)

- Portable core + new transport layer + channel mapping compile cleanly.
- Test executable passes, including: ring wraparound/desync, conversion, config,
  telemetry, channel mapping, interleave/deinterleave, transport underrun
  silence, threaded capture->input loopback (ordering and channel integrity),
  slip-on-overflow, output path, and config validation.
- Same tests clean under ThreadSanitizer and AddressSanitizer + UBSan.

## Written but NOT compiled or run (no Windows toolchain or ASIO SDK here)

- `src/windows/wasapi_backend.{hpp,cpp}` (WASAPI capture/render, reconnect, MMCSS).
- `src/windows/crystal_asio_driver.cpp` (ASIO COM driver wired to the backend).
- CMake `ENABLE_ASIO` target.

Expect to fix compile-level issues on first MSVC build against the real SDK
headers. Nothing below has been exercised.

## Still open (see RELEASE_GATES.md)

MSVC x64 build, ASIO host load/registration, real DAW and interface tests,
latency measurement, 24-hour and rapid start/stop/disconnect stability,
Opus-enabled build on Windows.
