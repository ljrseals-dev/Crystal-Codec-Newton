#!/bin/sh
# Crystal Codec - Newton | Crystal City | Lewis J. Seals Jr. (Therealla) - ljrseals-dev
# Install Crystal Codec - Newton (Core Audio HAL driver). Run from the build directory.
set -e
BUNDLE="${1:-CrystalCodec.driver}"
DEST="/Library/Audio/Plug-Ins/HAL"
[ -d "$BUNDLE" ] || { echo "Bundle not found: $BUNDLE" >&2; exit 1; }
codesign --force --sign "${CODESIGN_IDENTITY:--}" "$BUNDLE"
sudo mkdir -p "$DEST"
sudo rm -rf "$DEST/$(basename "$BUNDLE")"
sudo cp -R "$BUNDLE" "$DEST/"
sudo chown -R root:wheel "$DEST/$(basename "$BUNDLE")"
sudo killall coreaudiod || true   # coreaudiod restarts automatically
echo "Installed. Select 'Crystal Codec - Newton' in System Settings > Sound."
