/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/transport.hpp
 *  Purpose:    Portable capture/codec/ASIO data path: rings, worker, drift slip, latency
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <thread>

#include "crystal/audio_ring_buffer.hpp"
#include "crystal/opus_codec.hpp"
#include "crystal/telemetry.hpp"

namespace crystal {

struct TransportConfig {
    int sample_rate{48000};
    int channels{2};
    std::size_t asio_buffer_frames{128};
    bool opus_enabled{false};
    OpusMode opus_mode{OpusMode::Balanced10ms};
    int opus_complexity{10};
    std::size_t ring_frames{0};  // 0 = derive from asio_buffer_frames
};

// Platform-independent data path between a capture/render device and an ASIO
// host:
//
//   capture thread --push_capture--> [capture ring] --worker (codec)-->
//        [input ring] --pull_input--> ASIO host input buffers
//   ASIO host output buffers --push_output--> [output ring] --pull_render-->
//        render thread
//
// Every ring has exactly one producer and one consumer thread:
//   capture ring : producer = capture thread,  consumer = worker
//   input ring   : producer = worker,          consumer = ASIO callback thread
//   output ring  : producer = ASIO callback,   consumer = render thread
//
// Clock drift between independent devices is handled by level-based slip on
// the ASIO input side: when the input ring runs above its high watermark the
// oldest frames are discarded back to the target fill (counted as an overrun);
// when it runs dry the shortfall is zero-filled (counted as an underrun). This
// is slip compensation, not asynchronous resampling.
//
// All push_/pull_ functions are noexcept, allocation-free and lock-free.
class Transport final {
public:
    [[nodiscard]] static std::unique_ptr<Transport> create(const TransportConfig& config,
                                                           std::string& error);
    ~Transport();
    Transport(const Transport&) = delete;
    Transport& operator=(const Transport&) = delete;

    // Starts / stops the codec worker thread. stop() is idempotent.
    [[nodiscard]] bool start(std::string& error);
    void stop() noexcept;

    // Pre-fills the input ring with `frames` of silence so the reader has a
    // deterministic cushion that absorbs worker scheduling jitter. Only valid
    // before start() (no producer running). Adds `frames` of latency.
    void prime_input(std::size_t frames) noexcept;

    // Device side -----------------------------------------------------------
    void push_capture(const float* interleaved, std::size_t frames) noexcept;
    // Always fills `frames` frames; shortfall is silence. Returns frames that
    // were real data.
    std::size_t pull_render(float* interleaved, std::size_t frames) noexcept;

    // ASIO side -------------------------------------------------------------
    std::size_t pull_input(float* interleaved, std::size_t frames) noexcept;
    void push_output(const float* interleaved, std::size_t frames) noexcept;

    // Latency this layer adds, in frames (excludes device and host buffers).
    [[nodiscard]] std::size_t input_latency_frames() const noexcept;
    [[nodiscard]] std::size_t output_latency_frames() const noexcept;

    [[nodiscard]] bool codec_active() const noexcept { return codec_ != nullptr; }
    [[nodiscard]] Telemetry& telemetry() noexcept { return telemetry_; }
    [[nodiscard]] const TransportConfig& config() const noexcept { return config_; }
    // Folds ring desync flags into telemetry. Control thread only.
    [[nodiscard]] bool check_health() noexcept;

private:
    explicit Transport(const TransportConfig& config);
    void worker_loop() noexcept;
    void drain_once() noexcept;

    TransportConfig config_;
    std::size_t target_fill_{0};
    std::size_t high_water_{0};
    std::unique_ptr<AudioRingBuffer> capture_ring_;
    std::unique_ptr<AudioRingBuffer> input_ring_;
    std::unique_ptr<AudioRingBuffer> output_ring_;
    std::unique_ptr<OpusCodec> codec_;
    std::unique_ptr<float[]> work_pcm_;       // worker scratch (interleaved)
    std::unique_ptr<float[]> decoded_pcm_;    // worker scratch (interleaved)
    std::unique_ptr<unsigned char[]> packet_; // worker scratch
    std::unique_ptr<float[]> slip_scratch_;   // ASIO-thread scratch
    std::size_t work_frames_{0};
    std::size_t primed_frames_{0};
    Telemetry telemetry_;
    std::thread worker_;
    std::atomic<std::uint32_t> wake_{0};
    std::atomic<bool> stop_{false};
    std::atomic<bool> running_{false};
};

} // namespace crystal
