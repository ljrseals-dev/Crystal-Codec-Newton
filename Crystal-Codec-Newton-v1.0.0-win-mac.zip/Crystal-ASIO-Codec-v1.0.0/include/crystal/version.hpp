/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/version.hpp
 *  Purpose:    Version macros and constants
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once

#define CRYSTAL_VERSION_MAJOR 1
#define CRYSTAL_VERSION_MINOR 0
#define CRYSTAL_VERSION_PATCH 0
#define CRYSTAL_VERSION_STRING "1.0.0"

namespace crystal {
inline constexpr int version_major = CRYSTAL_VERSION_MAJOR;
inline constexpr int version_minor = CRYSTAL_VERSION_MINOR;
inline constexpr int version_patch = CRYSTAL_VERSION_PATCH;
inline constexpr const char* version_string = CRYSTAL_VERSION_STRING;
}
