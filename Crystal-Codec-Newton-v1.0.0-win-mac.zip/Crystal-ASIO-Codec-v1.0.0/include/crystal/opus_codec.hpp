/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/opus_codec.hpp
 *  Purpose:    Opus encode/decode wrapper with passthrough fallback
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

namespace crystal {

enum class OpusMode { UltraLow5ms, Balanced10ms, Standard20ms };

struct OpusConfig {
    int sample_rate{48000};
    int channels{2};
    OpusMode mode{OpusMode::Balanced10ms};
    int complexity{10};
    bool vbr{true};
};

// Uses libopus when CRYSTAL_HAVE_OPUS is enabled. Otherwise creation fails
// clearly; the application can use the passthrough path without pretending
// compression occurred.
//
// Buffer contract (enforced defensively):
//   encode(): `packet` must point to at least `capacity` bytes, and
//             `capacity` must be >= 0. `frames` must equal frame_size().
//   decode(): `pcm` must point to at least `max_frames * channels` floats,
//             and `max_frames` must be >= frame_size(). Undersized buffers
//             are rejected with -1 BEFORE the decoder is invoked.
class OpusCodec final {
public:
    [[nodiscard]] static std::unique_ptr<OpusCodec> create(const OpusConfig& config,
                                                           std::string& error);
    ~OpusCodec();
    OpusCodec(const OpusCodec&) = delete;
    OpusCodec& operator=(const OpusCodec&) = delete;

    [[nodiscard]] int encode(const float* pcm, int frames,
                             unsigned char* packet, int capacity) noexcept;
    [[nodiscard]] int decode(const unsigned char* packet, int packet_bytes,
                             float* pcm, int max_frames) noexcept;

    [[nodiscard]] std::size_t frame_size() const noexcept { return frame_size_; }
    [[nodiscard]] std::size_t get_total_latency_frames() const noexcept {
        return lookahead_frames_ + frame_size_ + margin_frames_;
    }
    [[nodiscard]] std::size_t lookahead_frames() const noexcept { return lookahead_frames_; }
    [[nodiscard]] int channels() const noexcept { return config_.channels; }

    // Hard upper bound on a single Opus packet. 1275 bytes per RFC 6716 plus
    // generous headroom for future extensions. Used to reject absurd inputs
    // before libopus is touched.
    static constexpr int kMaxOpusPacketBytes = 4096;

    void reset() noexcept;

private:
    explicit OpusCodec(const OpusConfig& config);
    struct Impl;
    std::unique_ptr<Impl> impl_;
    OpusConfig config_;
    std::size_t frame_size_{0};
    std::size_t lookahead_frames_{0};
    std::size_t margin_frames_{0};
};

} // namespace crystal
