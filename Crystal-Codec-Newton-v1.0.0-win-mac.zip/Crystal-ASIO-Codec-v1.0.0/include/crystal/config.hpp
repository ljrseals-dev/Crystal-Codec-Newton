/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/config.hpp
 *  Purpose:    Codec configuration model, validation and loading
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <cstdint>
#include <string>
namespace crystal {
struct Config {
    std::uint32_t version{1};
    int sample_rate{48000};
    int channels{2};
    int asio_buffer_frames{64};
    bool opus_enabled{false};
    int opus_frame_ms{10};
    bool wasapi_exclusive{false};
};
bool validate_config(const Config& config, std::string& error) noexcept;
bool save_config(const Config& config, const std::string& path, std::string& error);
bool load_config(const std::string& path, Config& config, std::string& error);
}
