/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/channel_map.hpp
 *  Purpose:    Interleave/deinterleave and channel-count mapping
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <cstddef>

namespace crystal {

// Interleaved <-> planar helpers and channel-count mapping. All functions are
// allocation-free and safe on the realtime thread. Buffers must not alias.

// Map `frames` interleaved frames from src_ch channels to dst_ch channels.
//   equal counts : copy
//   mono -> N    : duplicate
//   N -> mono    : average
//   otherwise    : copy min(src_ch, dst_ch) channels, zero any extra outputs
void map_channels(const float* src, std::size_t src_ch,
                  float* dst, std::size_t dst_ch, std::size_t frames) noexcept;

// planar[c][i] -> out[i * channels + c]. A null planar[c] yields silence.
void interleave(const float* const* planar, std::size_t channels,
                float* out, std::size_t frames) noexcept;

// in[i * channels + c] -> planar[c][i]. A null planar[c] is skipped.
void deinterleave(const float* in, float* const* planar, std::size_t channels,
                  std::size_t frames) noexcept;

} // namespace crystal
