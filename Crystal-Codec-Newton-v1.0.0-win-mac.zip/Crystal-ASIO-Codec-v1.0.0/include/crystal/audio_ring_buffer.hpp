/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/audio_ring_buffer.hpp
 *  Purpose:    Lock-free single-producer/single-consumer audio ring buffer
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <memory>

namespace crystal {

// Single-producer/single-consumer, interleaved float-frame ring.
// Exactly one thread may write and one thread may read while active.
//
// Contract:
//   - Construct and allocate before streaming begins.
//   - write_frames() is producer-only. read_frames() is consumer-only.
//   - clear_quiescent() may only be called after BOTH threads stop.
//   - In debug builds, clear_quiescent() asserts that no producer/consumer
//     is active. In release, it is a no-op safety reset.
class AudioRingBuffer final {
public:
    AudioRingBuffer(std::size_t capacity_frames, std::size_t channels);
    ~AudioRingBuffer() = default;
    AudioRingBuffer(const AudioRingBuffer&) = delete;
    AudioRingBuffer& operator=(const AudioRingBuffer&) = delete;
    AudioRingBuffer(AudioRingBuffer&&) = delete;
    AudioRingBuffer& operator=(AudioRingBuffer&&) = delete;

    [[nodiscard]] std::size_t write_frames(const float* interleaved, std::size_t frames) noexcept;
    [[nodiscard]] std::size_t read_frames(float* interleaved, std::size_t frames) noexcept;
    [[nodiscard]] std::size_t available_frames() const noexcept;
    [[nodiscard]] std::size_t free_frames() const noexcept;
    [[nodiscard]] std::size_t capacity_frames() const noexcept { return capacity_frames_; }
    [[nodiscard]] std::size_t channels() const noexcept { return channels_; }

    // True if a producer/consumer desync was ever detected. Monotonic.
    // A true value means the clamp in write/read has fired at least once:
    // the counters disagreed, and the ring reported full/empty defensively.
    // Treat this as a hard fault in release diagnostics.
    [[nodiscard]] bool desync_detected() const noexcept {
        return desync_.load(std::memory_order_relaxed) != 0;
    }

    // Fill the ring with silence and reset counters.
    // MUST be called with producer and consumer stopped.
    void clear_quiescent() noexcept;

    // Debug-only: mark the producer/consumer active. Not part of the RT
    // contract; intended for tests and host integration to catch misuse.
    void mark_producer_active(bool active) noexcept {
        producer_active_.store(active, std::memory_order_relaxed);
    }
    void mark_consumer_active(bool active) noexcept {
        consumer_active_.store(active, std::memory_order_relaxed);
    }

private:
    static std::size_t next_power_of_two(std::size_t n);
    const std::size_t capacity_frames_;
    const std::size_t mask_;
    const std::size_t channels_;
    std::unique_ptr<float[]> data_;
    alignas(64) std::atomic<std::uint64_t> read_idx_{0};
    alignas(64) std::atomic<std::uint64_t> write_idx_{0};
    alignas(64) std::atomic<std::uint32_t> desync_{0};
    std::atomic<bool> producer_active_{false};
    std::atomic<bool> consumer_active_{false};
};

} // namespace crystal
