/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/telemetry.hpp
 *  Purpose:    Lock-free runtime telemetry counters and snapshot reporting
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <atomic>
#include <cstdint>
#include <string>

namespace crystal {

struct TelemetrySnapshot {
    std::uint64_t underruns{};
    std::uint64_t overruns{};
    std::uint64_t buffer_switches{};
    std::uint64_t frames{};
    std::uint64_t desyncs{};
};

// Lock-free counters for the audio path. All record_* methods are safe to call
// from the realtime thread (relaxed atomics, no allocation, no locks).
//
// to_json() ALLOCATES. It is a control-thread function only. Do not call it
// from any audio callback, ASIO bufferSwitch, WASAPI thread, or worker loop.
class Telemetry final {
public:
    void record_underrun() noexcept { underruns_.fetch_add(1, std::memory_order_relaxed); }
    void record_overrun() noexcept  { overruns_.fetch_add(1, std::memory_order_relaxed); }
    void record_desync() noexcept   { desyncs_.fetch_add(1, std::memory_order_relaxed); }

    void record_switch(std::uint64_t frames) noexcept {
        switches_.fetch_add(1, std::memory_order_relaxed);
        frames_.fetch_add(frames, std::memory_order_relaxed);
    }

    void reset() noexcept;
    [[nodiscard]] TelemetrySnapshot snapshot() const noexcept;

    // Control-thread only. Allocates a std::string.
    [[nodiscard]] std::string to_json() const;

private:
    std::atomic<std::uint64_t> underruns_{0};
    std::atomic<std::uint64_t> overruns_{0};
    std::atomic<std::uint64_t> switches_{0};
    std::atomic<std::uint64_t> frames_{0};
    std::atomic<std::uint64_t> desyncs_{0};
};

} // namespace crystal
