/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/sample_convert.hpp
 *  Purpose:    PCM/float sample format conversion
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <cstddef>
#include <cstdint>
namespace crystal {
enum class SampleFormat { Float32, Pcm16, Pcm24, Pcm32 };
bool to_float(const void* src, float* dst, std::size_t samples, SampleFormat format) noexcept;
bool from_float(const float* src, void* dst, std::size_t samples, SampleFormat format) noexcept;
}
