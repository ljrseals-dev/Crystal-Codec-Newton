/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       include/crystal/rt_guard.hpp
 *  Purpose:    Real-time audio-thread denormal (FTZ/DAZ) guard
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#include <cstdint>

namespace crystal {

// RAII denormal guard for the audio thread.
//
// On x86/x86_64, subnormal (denormal) floats in filter tails and converter
// output can cost 10-100x normal latency on some microarchitectures. Setting
// FTZ (flush-to-zero) and DAZ (denormals-are-zero) in MXCSR eliminates the
// penalty. This is the "no frost" property: we prevent the slow path from
// ever accumulating.
//
// On ARM64, the equivalent is FPCR.FZ. On other platforms, this is a no-op.
//
// Construct one of these at the top of every audio callback, ASIO bufferSwitch,
// WASAPI capture/render thread, and worker loop. Do NOT construct inside a
// tight inner loop; construct once per callback.
class RtDenormalGuard final {
public:
    RtDenormalGuard() noexcept;
    ~RtDenormalGuard() noexcept;
    RtDenormalGuard(const RtDenormalGuard&) = delete;
    RtDenormalGuard& operator=(const RtDenormalGuard&) = delete;

    // Returns true if the current thread has FTZ/DAZ active.
    // Used by tests; not intended for the RT path.
    [[nodiscard]] static bool current_thread_has_flush() noexcept;

private:
    std::uint32_t saved_{0};
    std::uint64_t saved_fpcr_{0};
    bool active_{false};
};

} // namespace crystal
