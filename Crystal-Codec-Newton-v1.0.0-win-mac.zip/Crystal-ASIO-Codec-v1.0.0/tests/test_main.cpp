/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       tests/test_main.cpp
 *  Purpose:    Unit tests: ring wraparound/desync, codec, conversion, config, telemetry
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/audio_ring_buffer.hpp"
#include "crystal/channel_map.hpp"
#include "crystal/config.hpp"
#include "crystal/opus_codec.hpp"
#include "crystal/rt_guard.hpp"
#include "crystal/sample_convert.hpp"
#include "crystal/telemetry.hpp"
#include "crystal/transport.hpp"

#include <array>
#include <atomic>
#include <chrono>
#include <thread>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

namespace {

int failures = 0;
#define CHECK(x) do { \
    if (!(x)) { \
        std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << " " #x "\n"; \
        ++failures; \
    } \
} while (false)

void test_ring() {
    crystal::AudioRingBuffer ring(8, 2);
    std::array<float, 16> in{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}, out{};
    CHECK(ring.write_frames(in.data(), 4) == 4);
    CHECK(ring.read_frames(out.data(), 3) == 3);
    CHECK(ring.write_frames(in.data() + 6, 5) == 5);
    std::array<float, 12> got{};
    CHECK(ring.read_frames(got.data(), 6) == 6);
    CHECK(got[0] == 6 && got[1] == 7 && got[2] == 6 && got[3] == 7 &&
          got[10] == 14 && got[11] == 15);
    CHECK(ring.available_frames() == 0);
}

void test_ring_desync_flag() {
    crystal::AudioRingBuffer ring(8, 1);
    CHECK(!ring.desync_detected());
    std::array<float, 8> in{0,1,2,3,4,5,6,7}, out{};
    CHECK(ring.write_frames(in.data(), 8) == 8);
    CHECK(!ring.desync_detected());
    CHECK(ring.read_frames(out.data(), 8) == 8);
    CHECK(!ring.desync_detected());
}

void test_ring_clear_refills_silence() {
    crystal::AudioRingBuffer ring(8, 1);
    std::array<float, 8> in{1,2,3,4,5,6,7,8}, out{};
    CHECK(ring.write_frames(in.data(), 8) == 8);
    ring.clear_quiescent();
    CHECK(ring.write_frames(in.data(), 2) == 2);
    CHECK(ring.read_frames(out.data(), 2) == 2);
    CHECK(out[0] == 1.0F && out[1] == 2.0F);
}

void test_convert() {
    std::array<std::int16_t, 4> pcm{-32768, -1, 0, 32767};
    std::array<float, 4> f{};
    CHECK(crystal::to_float(pcm.data(), f.data(), f.size(),
                            crystal::SampleFormat::Pcm16));
    CHECK(f[0] == -1.0F && f[2] == 0.0F && f[3] > 0.99F);

    std::array<std::uint8_t, 3> p24{0x00, 0x00, 0x80};
    float x = 0;
    CHECK(crystal::to_float(p24.data(), &x, 1, crystal::SampleFormat::Pcm24));
    CHECK(x == -1.0F);

    // Round-trip PCM16
    std::array<std::int16_t, 4> back{};
    CHECK(crystal::from_float(f.data(), back.data(), f.size(),
                              crystal::SampleFormat::Pcm16));
    CHECK(back[0] == -32767 && back[3] == 32766);
}

void test_config() {
    crystal::Config c{};
    std::string e;
    CHECK(crystal::validate_config(c, e));
    c.asio_buffer_frames = 1;
    CHECK(!crystal::validate_config(c, e));
}

void test_telemetry() {
    crystal::Telemetry t;
    t.record_underrun();
    t.record_switch(64);
    t.record_desync();
    auto s = t.snapshot();
    CHECK(s.underruns == 1 && s.buffer_switches == 1 && s.frames == 64 && s.desyncs == 1);
    CHECK(t.to_json().find("\"frames\":64") != std::string::npos);
    CHECK(t.to_json().find("\"desyncs\":1") != std::string::npos);
}

void test_opus_unavailable_is_explicit() {
    crystal::OpusConfig c{};
    std::string e;
#ifndef CRYSTAL_HAVE_OPUS
    CHECK(crystal::OpusCodec::create(c, e) == nullptr);
    CHECK(!e.empty());
#endif
}

void test_opus_decode_rejects_undersized() {
    crystal::OpusConfig c{};
    std::string e;
    auto codec = crystal::OpusCodec::create(c, e);
#ifdef CRYSTAL_HAVE_OPUS
    if (codec) {
        float pcm[2] = {0, 0};
        CHECK(codec->decode(nullptr, 0, pcm, 1) == -1);
        CHECK(codec->decode(nullptr, -1, pcm,
              static_cast<int>(codec->frame_size())) == -1);
        CHECK(codec->decode(nullptr, 1 << 20, pcm,
              static_cast<int>(codec->frame_size())) == -1);
        CHECK(codec->decode(nullptr, 10, pcm,
              static_cast<int>(codec->frame_size())) == -1);
    }
#else
    CHECK(codec == nullptr);
    CHECK(!e.empty());
#endif
}

void test_rt_denormal_guard_scope() {
    const bool before = crystal::RtDenormalGuard::current_thread_has_flush();
    {
        crystal::RtDenormalGuard g;
#if defined(__x86_64__) || defined(_M_X64) || defined(__i386__) || defined(_M_IX86) \
    || defined(__aarch64__)
        CHECK(crystal::RtDenormalGuard::current_thread_has_flush());
#endif
    }
    CHECK(crystal::RtDenormalGuard::current_thread_has_flush() == before);
}

void test_channel_map() {
    const float mono[3] = {1, 2, 3};
    float st[6]{};
    crystal::map_channels(mono, 1, st, 2, 3);
    CHECK(st[0] == 1 && st[1] == 1 && st[4] == 3 && st[5] == 3);
    float back[3]{};
    const float s2[6] = {1, 3, 2, 4, 5, 7};
    crystal::map_channels(s2, 2, back, 1, 3);
    CHECK(back[0] == 2 && back[1] == 3 && back[2] == 6);
    float six[12]{};
    crystal::map_channels(s2, 2, six, 6, 1);
    CHECK(six[0] == 1 && six[1] == 3 && six[2] == 0 && six[5] == 0);

    float l[4] = {1, 2, 3, 4}, r[4] = {5, 6, 7, 8};
    const float* planar_in[2] = {l, r};
    float inter[8]{};
    crystal::interleave(planar_in, 2, inter, 4);
    CHECK(inter[0] == 1 && inter[1] == 5 && inter[6] == 4 && inter[7] == 8);
    float l2[4]{}, r2[4]{};
    float* planar_out[2] = {l2, r2};
    crystal::deinterleave(inter, planar_out, 2, 4);
    CHECK(l2[2] == 3 && r2[3] == 8);
    const float* with_null[2] = {l, nullptr};
    crystal::interleave(with_null, 2, inter, 4);
    CHECK(inter[1] == 0 && inter[2] == 2);
}

void test_transport_validation() {
    crystal::TransportConfig c;
    std::string e;
    c.asio_buffer_frames = 4;
    CHECK(crystal::Transport::create(c, e) == nullptr && !e.empty());
    c.asio_buffer_frames = 128;
    c.channels = 0;
    CHECK(crystal::Transport::create(c, e) == nullptr);
#ifndef CRYSTAL_HAVE_OPUS
    c.channels = 2;
    c.opus_enabled = true;
    e.clear();
    CHECK(crystal::Transport::create(c, e) == nullptr && !e.empty());
#endif
}

void test_transport_underrun_is_silence() {
    crystal::TransportConfig c;
    std::string e;
    auto t = crystal::Transport::create(c, e);
    CHECK(t != nullptr);
    if (!t) return;
    std::array<float, 256> buf;
    buf.fill(9.0F);
    CHECK(t->pull_input(buf.data(), 128) == 0);
    CHECK(buf[0] == 0.0F && buf[255] == 0.0F);
    buf.fill(9.0F);
    CHECK(t->pull_render(buf.data(), 128) == 0);
    CHECK(buf[0] == 0.0F && buf[255] == 0.0F);
    CHECK(t->telemetry().snapshot().underruns == 2);
}

void test_transport_loopback_threads() {
    crystal::TransportConfig c;
    c.asio_buffer_frames = 64;
    std::string e;
    auto t = crystal::Transport::create(c, e);
    CHECK(t != nullptr);
    if (!t) return;
    CHECK(t->start(e));
    constexpr std::size_t kBlocks = 400, kFrames = 64;
    std::thread cap([&] {
        std::array<float, kFrames * 2> blk;
        std::uint32_t n = 0;
        for (std::size_t b = 0; b < kBlocks; ++b) {
            for (std::size_t i = 0; i < kFrames; ++i, ++n) {
                blk[i * 2] = static_cast<float>(n);
                blk[i * 2 + 1] = -static_cast<float>(n);
            }
            t->push_capture(blk.data(), kFrames);
            std::this_thread::sleep_for(std::chrono::microseconds(200));
        }
    });
    // Consume until we have seen every frame once or time out. Data must be
    // strictly in order; zero-fill (underrun) is allowed only before the ramp.
    std::array<float, kFrames * 2> out;
    std::size_t seen = 0;
    float last = -1.0F;
    bool ordered = true, mirrored = true;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
    while (seen < kBlocks * kFrames && std::chrono::steady_clock::now() < deadline) {
        const std::size_t got = t->pull_input(out.data(), kFrames);
        for (std::size_t i = 0; i < got; ++i) {
            if (out[i * 2] <= last) ordered = false;
            if (out[i * 2 + 1] != -out[i * 2]) mirrored = false;
            last = out[i * 2];
        }
        seen += got;
        if (got == 0) std::this_thread::sleep_for(std::chrono::microseconds(100));
    }
    cap.join();
    t->stop();
    CHECK(ordered);
    CHECK(mirrored);
    // A slow consumer may legitimately trigger slip (counted); otherwise no loss.
    CHECK(seen == kBlocks * kFrames || t->telemetry().snapshot().overruns > 0);
    CHECK(t->check_health());
}

void test_transport_slip_discards_oldest() {
    crystal::TransportConfig c;
    c.asio_buffer_frames = 64;
    std::string e;
    auto t = crystal::Transport::create(c, e);
    CHECK(t != nullptr);
    if (!t) return;
    CHECK(t->start(e));
    // Flood far past the high-water mark with a ramp, with no consumer.
    std::array<float, 128> blk;
    std::uint32_t n = 0;
    for (int b = 0; b < 40; ++b) {
        for (int i = 0; i < 64; ++i, ++n) { blk[i * 2] = static_cast<float>(n); blk[i * 2 + 1] = 0; }
        t->push_capture(blk.data(), 64);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    t->stop();
    std::array<float, 128> out;
    CHECK(t->pull_input(out.data(), 64) == 64);
    // Oldest frames were discarded: the first delivered frame is not frame 0,
    // and the overrun was counted.
    CHECK(out[0] > 0.0F);
    CHECK(t->telemetry().snapshot().overruns >= 1);
}

void test_transport_output_path() {
    crystal::TransportConfig c;
    std::string e;
    auto t = crystal::Transport::create(c, e);
    CHECK(t != nullptr);
    if (!t) return;
    std::array<float, 256> in, out{};
    for (std::size_t i = 0; i < in.size(); ++i) in[i] = static_cast<float>(i);
    t->push_output(in.data(), 128);
    CHECK(t->pull_render(out.data(), 128) == 128);
    CHECK(out[0] == 0.0F && out[255] == 255.0F);
    CHECK(t->output_latency_frames() == c.asio_buffer_frames);
    CHECK(t->input_latency_frames() >= c.asio_buffer_frames);
}

void test_transport_passthrough_is_bit_exact() {
    crystal::TransportConfig c;
    c.asio_buffer_frames = 64;
    std::string e;
    auto t = crystal::Transport::create(c, e);
    CHECK(t != nullptr);
    if (!t) return;
    t->prime_input(64);
    CHECK(t->input_latency_frames() >= 128);
    CHECK(t->start(e));
    std::vector<float> in(64 * 2), got(64 * 2 * 2, 1.0F);
    std::uint32_t x = 12345;
    for (auto& v : in) {  // arbitrary float bit patterns incl. subnormal-ish values
        x = x * 1664525u + 1013904223u;
        v = static_cast<float>(static_cast<std::int32_t>(x)) / 2147483648.0F;
    }
    t->push_capture(in.data(), 64);
    std::size_t seen = 0;
    std::vector<float> all;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    while (seen < 128 && std::chrono::steady_clock::now() < deadline) {
        std::vector<float> blk(64 * 2);
        const std::size_t n = t->pull_input(blk.data(), 64);
        all.insert(all.end(), blk.begin(), blk.end());
        seen += 64;
        (void)n;
        if (all.size() >= 256) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    t->stop();
    // First 64 frames are the primed silence, the next 64 must match bit for bit.
    CHECK(all.size() >= 256);
    if (all.size() >= 256) {
        bool silent = true;
        for (std::size_t i = 0; i < 128; ++i) if (all[i] != 0.0F) silent = false;
        CHECK(silent);
        CHECK(std::memcmp(all.data() + 128, in.data(), 128 * sizeof(float)) == 0);
    }
}

} // namespace

int main() {
    test_ring();
    test_ring_desync_flag();
    test_ring_clear_refills_silence();
    test_convert();
    test_config();
    test_telemetry();
    test_opus_unavailable_is_explicit();
    test_opus_decode_rejects_undersized();
    test_rt_denormal_guard_scope();
    test_channel_map();
    test_transport_validation();
    test_transport_underrun_is_silence();
    test_transport_loopback_threads();
    test_transport_slip_discards_oldest();
    test_transport_output_path();
    test_transport_passthrough_is_bit_exact();

    if (failures) {
        std::cerr << failures << " test(s) failed\n";
        return EXIT_FAILURE;
    }
    std::cout << "Crystal ASIO Codec core tests passed\n";
    return EXIT_SUCCESS;
}
