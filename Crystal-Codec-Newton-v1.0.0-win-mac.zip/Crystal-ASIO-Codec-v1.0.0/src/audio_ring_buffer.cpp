/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/audio_ring_buffer.cpp
 *  Purpose:    Lock-free single-producer/single-consumer audio ring buffer
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/audio_ring_buffer.hpp"
#include <algorithm>
#include <cassert>
#include <cstring>
#include <limits>
#include <stdexcept>

namespace crystal {
namespace {
std::size_t checked_sample_count(std::size_t frames, std::size_t channels) {
    if (channels == 0 || frames > std::numeric_limits<std::size_t>::max() / channels)
        throw std::invalid_argument("invalid ring dimensions");
    return frames * channels;
}
}

std::size_t AudioRingBuffer::next_power_of_two(std::size_t n) {
    if (n < 2) n = 2;
    if (n > (std::numeric_limits<std::size_t>::max() >> 1U))
        throw std::invalid_argument("ring capacity too large");
    --n;
    for (std::size_t shift = 1; shift < sizeof(std::size_t) * 8; shift <<= 1U) n |= n >> shift;
    return n + 1;
}

AudioRingBuffer::AudioRingBuffer(std::size_t capacity_frames, std::size_t channels)
    : capacity_frames_(next_power_of_two(capacity_frames)), mask_(capacity_frames_ - 1),
      channels_(channels),
      data_(std::make_unique<float[]>(checked_sample_count(capacity_frames_, channels))) {
    std::memset(data_.get(), 0, capacity_frames_ * channels_ * sizeof(float));
}

std::size_t AudioRingBuffer::write_frames(const float* input, std::size_t frames) noexcept {
    if (input == nullptr || frames == 0) return 0;

    const auto w = write_idx_.load(std::memory_order_relaxed);
    const auto r = read_idx_.load(std::memory_order_acquire);

    // Monotonic counters. Capacity is always far below 2^63, so a difference
    // greater than capacity means the counters desynced.
    const auto used64 = w - r;
    if (used64 > capacity_frames_) {
        desync_.store(1, std::memory_order_relaxed);
    }
    const auto used = used64 > capacity_frames_
        ? capacity_frames_ : static_cast<std::size_t>(used64);

    const auto count = std::min(frames, capacity_frames_ - used);
    const auto start_frame = static_cast<std::size_t>(w) & mask_;
    const auto first = std::min(count, capacity_frames_ - start_frame);

    std::memcpy(data_.get() + start_frame * channels_, input,
                first * channels_ * sizeof(float));
    if (count > first)
        std::memcpy(data_.get(), input + first * channels_,
                    (count - first) * channels_ * sizeof(float));

    write_idx_.store(w + count, std::memory_order_release);
    return count;
}

std::size_t AudioRingBuffer::read_frames(float* output, std::size_t frames) noexcept {
    if (output == nullptr || frames == 0) return 0;

    const auto r = read_idx_.load(std::memory_order_relaxed);
    const auto w = write_idx_.load(std::memory_order_acquire);

    const auto available64 = w - r;
    if (available64 > capacity_frames_) {
        desync_.store(1, std::memory_order_relaxed);
    }
    const auto available = available64 > capacity_frames_
        ? capacity_frames_ : static_cast<std::size_t>(available64);

    const auto count = std::min(frames, available);
    const auto start_frame = static_cast<std::size_t>(r) & mask_;
    const auto first = std::min(count, capacity_frames_ - start_frame);

    std::memcpy(output, data_.get() + start_frame * channels_,
                first * channels_ * sizeof(float));
    if (count > first)
        std::memcpy(output + first * channels_, data_.get(),
                    (count - first) * channels_ * sizeof(float));

    read_idx_.store(r + count, std::memory_order_release);
    return count;
}

std::size_t AudioRingBuffer::available_frames() const noexcept {
    const auto r = read_idx_.load(std::memory_order_acquire);
    const auto w = write_idx_.load(std::memory_order_acquire);
    const auto n = w - r;
    return n > capacity_frames_ ? capacity_frames_ : static_cast<std::size_t>(n);
}

std::size_t AudioRingBuffer::free_frames() const noexcept {
    return capacity_frames_ - available_frames();
}

void AudioRingBuffer::clear_quiescent() noexcept {
#ifndef NDEBUG
    assert(!producer_active_.load(std::memory_order_relaxed) &&
           "clear_quiescent called while producer is active");
    assert(!consumer_active_.load(std::memory_order_relaxed) &&
           "clear_quiescent called while consumer is active");
#endif
    std::memset(data_.get(), 0, capacity_frames_ * channels_ * sizeof(float));
    read_idx_.store(0, std::memory_order_relaxed);
    write_idx_.store(0, std::memory_order_relaxed);
}

} // namespace crystal
