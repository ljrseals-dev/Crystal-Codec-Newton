/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/transport.cpp
 *  Purpose:    Portable capture/codec/ASIO data path: rings, worker, drift slip, latency
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/transport.hpp"

#include <algorithm>
#include <cstring>
#include <new>

#include "crystal/rt_guard.hpp"

namespace crystal {

namespace {
constexpr std::size_t kPassthroughChunk = 256;
constexpr std::size_t kSlipScratchFrames = 1024;
}  // namespace

Transport::Transport(const TransportConfig& config) : config_(config) {}

Transport::~Transport() { stop(); }

std::unique_ptr<Transport> Transport::create(const TransportConfig& config, std::string& error) {
    if (config.channels < 1 || config.channels > 64) { error = "Channel count out of range"; return nullptr; }
    if (config.sample_rate < 8000 || config.sample_rate > 384000) { error = "Sample rate out of range"; return nullptr; }
    if (config.asio_buffer_frames < 16 || config.asio_buffer_frames > 16384) { error = "ASIO buffer size out of range"; return nullptr; }

    std::unique_ptr<Transport> t(new (std::nothrow) Transport(config));
    if (!t) { error = "Out of memory"; return nullptr; }
    const std::size_t ch = static_cast<std::size_t>(config.channels);
    const std::size_t ring = config.ring_frames
        ? config.ring_frames
        : std::max<std::size_t>(config.asio_buffer_frames * 8, 4096);
    try {
        t->capture_ring_ = std::make_unique<AudioRingBuffer>(ring, ch);
        t->input_ring_ = std::make_unique<AudioRingBuffer>(ring, ch);
        t->output_ring_ = std::make_unique<AudioRingBuffer>(ring, ch);
        t->slip_scratch_ = std::make_unique<float[]>(kSlipScratchFrames * ch);
    } catch (...) { error = "Out of memory allocating rings"; return nullptr; }

    if (config.opus_enabled) {
        OpusConfig oc;
        oc.sample_rate = config.sample_rate;
        oc.channels = config.channels;
        oc.mode = config.opus_mode;
        oc.complexity = config.opus_complexity;
        t->codec_ = OpusCodec::create(oc, error);
        if (!t->codec_) return nullptr;  // never pretend compression happened
        t->work_frames_ = t->codec_->frame_size();
    } else {
        t->work_frames_ = kPassthroughChunk;
    }
    try {
        t->work_pcm_ = std::make_unique<float[]>(t->work_frames_ * ch);
        t->decoded_pcm_ = std::make_unique<float[]>(t->work_frames_ * ch);
        t->packet_ = std::make_unique<unsigned char[]>(OpusCodec::kMaxOpusPacketBytes);
    } catch (...) { error = "Out of memory allocating worker buffers"; return nullptr; }

    // Target fill: one ASIO period of cushion, plus one codec/worker chunk.
    t->target_fill_ = config.asio_buffer_frames + (t->codec_ ? t->work_frames_ : 0);
    t->high_water_ = t->target_fill_ + 2 * config.asio_buffer_frames;
    return t;
}

bool Transport::start(std::string& error) {
    if (running_.exchange(true)) return true;
    stop_.store(false, std::memory_order_release);
    try {
        worker_ = std::thread(&Transport::worker_loop, this);
    } catch (...) {
        running_.store(false);
        error = "Could not start codec worker thread";
        return false;
    }
    return true;
}

void Transport::stop() noexcept {
    if (!running_.exchange(false)) return;
    stop_.store(true, std::memory_order_release);
    wake_.fetch_add(1, std::memory_order_release);
    wake_.notify_all();
    if (worker_.joinable()) worker_.join();
}

void Transport::prime_input(std::size_t frames) noexcept {
    if (running_.load()) return;
    const std::size_t ch = static_cast<std::size_t>(config_.channels);
    std::size_t left = std::min(frames, input_ring_->free_frames());
    while (left > 0) {
        const std::size_t n = std::min(left, kSlipScratchFrames);
        std::memset(slip_scratch_.get(), 0, n * ch * sizeof(float));
        const std::size_t w = input_ring_->write_frames(slip_scratch_.get(), n);
        if (w == 0) break;
        left -= w;
    }
    primed_frames_ = std::min(frames, input_ring_->capacity_frames());
}

void Transport::push_capture(const float* interleaved, std::size_t frames) noexcept {
    if (!interleaved || frames == 0) return;
    const std::size_t wrote = capture_ring_->write_frames(interleaved, frames);
    if (wrote < frames) telemetry_.record_overrun();
    wake_.fetch_add(1, std::memory_order_release);
    wake_.notify_one();
}

std::size_t Transport::pull_render(float* interleaved, std::size_t frames) noexcept {
    if (!interleaved || frames == 0) return 0;
    const std::size_t ch = static_cast<std::size_t>(config_.channels);
    const std::size_t got = output_ring_->read_frames(interleaved, frames);
    if (got < frames) {
        std::memset(interleaved + got * ch, 0, (frames - got) * ch * sizeof(float));
        telemetry_.record_underrun();
    }
    return got;
}

std::size_t Transport::pull_input(float* interleaved, std::size_t frames) noexcept {
    if (!interleaved || frames == 0) return 0;
    const std::size_t ch = static_cast<std::size_t>(config_.channels);

    // Slip: discard the oldest frames if the clocks have drifted the ring high.
    std::size_t avail = input_ring_->available_frames();
    if (avail > high_water_) {
        std::size_t drop = avail - target_fill_;
        while (drop > 0) {
            const std::size_t n = std::min(drop, kSlipScratchFrames);
            const std::size_t r = input_ring_->read_frames(slip_scratch_.get(), n);
            if (r == 0) break;
            drop -= r;
        }
        telemetry_.record_overrun();
    }

    const std::size_t got = input_ring_->read_frames(interleaved, frames);
    if (got < frames) {
        std::memset(interleaved + got * ch, 0, (frames - got) * ch * sizeof(float));
        telemetry_.record_underrun();
    }
    return got;
}

void Transport::push_output(const float* interleaved, std::size_t frames) noexcept {
    if (!interleaved || frames == 0) return;
    if (output_ring_->write_frames(interleaved, frames) < frames) telemetry_.record_overrun();
}

std::size_t Transport::input_latency_frames() const noexcept {
    // Cushion held in the input ring plus codec lookahead/framing if active.
    return target_fill_ + primed_frames_ + (codec_ ? codec_->get_total_latency_frames() : 0);
}

std::size_t Transport::output_latency_frames() const noexcept {
    // Output ring is drained as soon as the ASIO period completes.
    return config_.asio_buffer_frames;
}

bool Transport::check_health() noexcept {
    bool bad = false;
    if (capture_ring_->desync_detected() || input_ring_->desync_detected() ||
        output_ring_->desync_detected()) {
        telemetry_.record_desync();
        bad = true;
    }
    return !bad;
}

void Transport::drain_once() noexcept {
    const std::size_t ch = static_cast<std::size_t>(config_.channels);
    if (codec_) {
        const std::size_t fs = codec_->frame_size();
        while (capture_ring_->available_frames() >= fs) {
            if (capture_ring_->read_frames(work_pcm_.get(), fs) != fs) break;
            const int bytes = codec_->encode(work_pcm_.get(), static_cast<int>(fs), packet_.get(),
                                             OpusCodec::kMaxOpusPacketBytes);
            if (bytes < 0) { telemetry_.record_desync(); continue; }
            const int out = codec_->decode(packet_.get(), bytes, decoded_pcm_.get(),
                                           static_cast<int>(fs));
            if (out <= 0) { telemetry_.record_desync(); continue; }
            const std::size_t n = static_cast<std::size_t>(out);
            if (input_ring_->write_frames(decoded_pcm_.get(), n) < n) telemetry_.record_overrun();
        }
    } else {
        for (;;) {
            const std::size_t n = capture_ring_->read_frames(work_pcm_.get(), kPassthroughChunk);
            if (n == 0) break;
            if (input_ring_->write_frames(work_pcm_.get(), n) < n) telemetry_.record_overrun();
        }
    }
    (void)ch;
}

void Transport::worker_loop() noexcept {
    RtDenormalGuard guard;
    capture_ring_->mark_consumer_active(true);
    input_ring_->mark_producer_active(true);
    for (;;) {
        const std::uint32_t seen = wake_.load(std::memory_order_acquire);
        drain_once();
        if (stop_.load(std::memory_order_acquire)) break;
        wake_.wait(seen, std::memory_order_acquire);  // returns when wake_ != seen
    }
    capture_ring_->mark_consumer_active(false);
    input_ring_->mark_producer_active(false);
}

} // namespace crystal
