/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/sample_convert.cpp
 *  Purpose:    PCM/float sample format conversion
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/sample_convert.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>

namespace crystal {
namespace {
template<class T> T load_unaligned(const void* p) noexcept { T v{}; std::memcpy(&v, p, sizeof(T)); return v; }
template<class T> void store_unaligned(void* p, T v) noexcept { std::memcpy(p, &v, sizeof(T)); }
float sane(float x) noexcept { return std::isfinite(x) ? std::clamp(x, -1.0F, 1.0F) : 0.0F; }
}
bool to_float(const void* src, float* dst, std::size_t n, SampleFormat fmt) noexcept {
    if ((!src || !dst) && n != 0) return false;
    const auto* p = static_cast<const std::uint8_t*>(src);
    for (std::size_t i=0; i<n; ++i) {
        switch (fmt) {
        case SampleFormat::Float32: dst[i] = sane(load_unaligned<float>(p+i*4)); break;
        case SampleFormat::Pcm16: dst[i] = static_cast<float>(load_unaligned<std::int16_t>(p+i*2))/32768.0F; break;
        case SampleFormat::Pcm24: {
            const auto* b=p+i*3;
            std::int32_t v=static_cast<std::int32_t>(b[0]) | (static_cast<std::int32_t>(b[1])<<8) | (static_cast<std::int32_t>(b[2])<<16);
            if ((v & 0x800000) != 0) v |= static_cast<std::int32_t>(0xFF000000U);
            dst[i]=static_cast<float>(v)/8388608.0F; break;
        }
        case SampleFormat::Pcm32: dst[i]=static_cast<float>(load_unaligned<std::int32_t>(p+i*4)/2147483648.0); break;
        default: return false;
        }
    }
    return true;
}
bool from_float(const float* src, void* dst, std::size_t n, SampleFormat fmt) noexcept {
    if ((!src || !dst) && n != 0) return false;
    auto* p=static_cast<std::uint8_t*>(dst);
    for (std::size_t i=0; i<n; ++i) {
        const float x=sane(src[i]);
        switch (fmt) {
        case SampleFormat::Float32: store_unaligned<float>(p+i*4,x); break;
        case SampleFormat::Pcm16: store_unaligned<std::int16_t>(p+i*2,static_cast<std::int16_t>(std::lrint(x*32767.0F))); break;
        case SampleFormat::Pcm24: {
            const auto v=static_cast<std::int32_t>(std::lrint(x*8388607.0F));
            p[i*3]=static_cast<std::uint8_t>(v & 0xFF); p[i*3+1]=static_cast<std::uint8_t>((v>>8)&0xFF); p[i*3+2]=static_cast<std::uint8_t>((v>>16)&0xFF); break;
        }
        case SampleFormat::Pcm32: {
            const auto v=static_cast<std::int64_t>(std::llrint(static_cast<double>(x)*2147483647.0));
            store_unaligned<std::int32_t>(p+i*4,static_cast<std::int32_t>(v)); break;
        }
        default: return false;
        }
    }
    return true;
}
} // namespace crystal
