/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/windows/wasapi_backend.cpp
 *  Purpose:    Event-driven WASAPI capture/render backend (Windows)
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "wasapi_backend.hpp"

#include <windows.h>
#include <mmsystem.h>
#include <audioclient.h>
#include <avrt.h>
#include <mmdeviceapi.h>
#include <mmreg.h>
#include <objbase.h>
#include <wrl/client.h>

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "crystal/channel_map.hpp"
#include "crystal/rt_guard.hpp"
#include "crystal/sample_convert.hpp"

namespace crystal {

namespace {

using Microsoft::WRL::ComPtr;

// Defined locally so the DLL needs no ksguid.lib / initguid.h.
const GUID kSubtypePcm   = {0x00000001, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}};
const GUID kSubtypeFloat = {0x00000003, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}};

constexpr std::size_t kCaptureChunkFrames = 4096;
constexpr DWORD kReconnectIntervalMs = 500;
constexpr DWORD kReadyTimeoutMs = 3000;
constexpr DWORD kEventTimeoutMs = 100;

struct DeviceFormat {
    SampleFormat sample{SampleFormat::Float32};
    int channels{2};
    int bytes_per_frame{8};
    int rate{48000};
};

// Classifies the ACTUAL negotiated WAVEFORMATEX / WAVEFORMATEXTENSIBLE
// subformat. Anything the converter cannot handle is rejected explicitly.
bool classify(const WAVEFORMATEX* wf, DeviceFormat& out) {
    if (!wf || wf->nChannels == 0) return false;
    const GUID* sub = nullptr;
    if (wf->wFormatTag == WAVE_FORMAT_EXTENSIBLE && wf->cbSize >= 22)
        sub = &reinterpret_cast<const WAVEFORMATEXTENSIBLE*>(wf)->SubFormat;
    const bool is_float = wf->wFormatTag == WAVE_FORMAT_IEEE_FLOAT ||
                          (sub && IsEqualGUID(*sub, kSubtypeFloat));
    const bool is_pcm = wf->wFormatTag == WAVE_FORMAT_PCM ||
                        (sub && IsEqualGUID(*sub, kSubtypePcm));
    if (is_float && wf->wBitsPerSample == 32) {
        out.sample = SampleFormat::Float32;
    } else if (is_pcm) {
        switch (wf->wBitsPerSample) {
            case 16: out.sample = SampleFormat::Pcm16; break;
            case 24: out.sample = SampleFormat::Pcm24; break;
            case 32: out.sample = SampleFormat::Pcm32; break;
            default: return false;
        }
    } else {
        return false;
    }
    out.channels = wf->nChannels;
    out.bytes_per_frame = wf->nBlockAlign;
    out.rate = static_cast<int>(wf->nSamplesPerSec);
    return true;
}

UINT32 hns_to_frames(REFERENCE_TIME hns, int rate) {
    if (hns < 0) hns = 0;
    return static_cast<UINT32>((hns * rate + 5000000) / 10000000);
}

std::string hr_text(const char* what, HRESULT hr) {
    char buf[96];
    std::snprintf(buf, sizeof(buf), "%s (HRESULT 0x%08lX)", what, static_cast<unsigned long>(hr));
    return buf;
}

struct Stream {
    ComPtr<IAudioClient> client;
    ComPtr<IAudioRenderClient> render;
    ComPtr<IAudioCaptureClient> capture;
    HANDLE event{nullptr};
    DeviceFormat fmt{};
    UINT32 buffer_frames{0};
    UINT32 latency_frames{0};
    bool low_latency{false};

    void close() {
        if (client) client->Stop();
        render.Reset();
        capture.Reset();
        client.Reset();
        if (event) { CloseHandle(event); event = nullptr; }
        buffer_frames = latency_frames = 0;
        low_latency = false;
    }
};

HRESULT activate(EDataFlow flow, ComPtr<IAudioClient>& client) {
    ComPtr<IMMDeviceEnumerator> en;
    HRESULT hr = CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL,
                                  IID_PPV_ARGS(&en));
    if (FAILED(hr)) return hr;
    ComPtr<IMMDevice> dev;
    hr = en->GetDefaultAudioEndpoint(flow, eConsole, &dev);
    if (FAILED(hr)) return hr;
    return dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr,
                         reinterpret_cast<void**>(client.GetAddressOf()));
}

WAVEFORMATEXTENSIBLE make_float_stereo(int rate) {
    WAVEFORMATEXTENSIBLE w{};
    w.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
    w.Format.nChannels = 2;
    w.Format.nSamplesPerSec = static_cast<DWORD>(rate);
    w.Format.wBitsPerSample = 32;
    w.Format.nBlockAlign = 8;
    w.Format.nAvgBytesPerSec = static_cast<DWORD>(rate) * 8;
    w.Format.cbSize = 22;
    w.Samples.wValidBitsPerSample = 32;
    w.dwChannelMask = SPEAKER_FRONT_LEFT | SPEAKER_FRONT_RIGHT;
    w.SubFormat = kSubtypeFloat;
    return w;
}

// Opens the default endpoint. Strategy, in order:
//   A. IAudioClient3 low-latency shared stream at the engine's minimum period
//      (only when the engine mix rate equals the ASIO rate).
//   B. Shared stream in float32/stereo at the ASIO rate with Windows' own
//      format + sample-rate conversion (AUTOCONVERTPCM | SRC_DEFAULT_QUALITY).
//   C. Shared stream in the engine mix format with manual conversion
//      (requires mix rate == ASIO rate).
// A failed Initialize leaves a client unusable, so each attempt re-activates.
bool open_stream(EDataFlow flow, int rate, Stream& s, std::string& error) {
    s.close();
    s.event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    if (!s.event) { error = "CreateEvent failed"; return false; }

    bool ok = false;
    HRESULT last = S_OK;

    // --- A ---
    {
        ComPtr<IAudioClient> c;
        if (SUCCEEDED(activate(flow, c))) {
            ComPtr<IAudioClient3> c3;
            if (SUCCEEDED(c.As(&c3))) {
                WAVEFORMATEX* mix = nullptr;
                DeviceFormat df;
                if (SUCCEEDED(c3->GetMixFormat(&mix)) && classify(mix, df) && df.rate == rate) {
                    UINT32 def = 0, fund = 0, mn = 0, mx = 0;
                    if (SUCCEEDED(c3->GetSharedModeEnginePeriod(mix, &def, &fund, &mn, &mx)) &&
                        SUCCEEDED(c3->InitializeSharedAudioStream(AUDCLNT_STREAMFLAGS_EVENTCALLBACK, mn, mix, nullptr))) {
                        s.client = c;
                        s.fmt = df;
                        s.low_latency = true;
                        ok = true;
                    }
                }
                if (mix) CoTaskMemFree(mix);
            }
        }
    }
    // --- B ---
    if (!ok) {
        ComPtr<IAudioClient> c;
        last = activate(flow, c);
        if (SUCCEEDED(last)) {
            WAVEFORMATEXTENSIBLE w = make_float_stereo(rate);
            last = c->Initialize(AUDCLNT_SHAREMODE_SHARED,
                                 AUDCLNT_STREAMFLAGS_EVENTCALLBACK | AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM |
                                     AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY,
                                 0, 0, &w.Format, nullptr);
            if (SUCCEEDED(last)) {
                s.client = c;
                classify(&w.Format, s.fmt);
                ok = true;
            }
        }
    }
    // --- C ---
    if (!ok) {
        ComPtr<IAudioClient> c;
        last = activate(flow, c);
        if (SUCCEEDED(last)) {
            WAVEFORMATEX* mix = nullptr;
            DeviceFormat df;
            last = c->GetMixFormat(&mix);
            if (SUCCEEDED(last)) {
                if (!classify(mix, df)) {
                    error = "Endpoint mix format is not PCM16/24/32 or float32";
                } else if (df.rate != rate) {
                    error = "Endpoint rate " + std::to_string(df.rate) + " Hz differs from ASIO rate " +
                            std::to_string(rate) + " Hz";
                } else {
                    last = c->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_EVENTCALLBACK, 0, 0, mix, nullptr);
                    if (SUCCEEDED(last)) { s.client = c; s.fmt = df; ok = true; }
                }
                CoTaskMemFree(mix);
            }
        }
    }
    if (!ok) {
        if (error.empty()) error = hr_text("Could not open default audio endpoint", last);
        s.close();
        return false;
    }

    HRESULT hr = s.client->SetEventHandle(s.event);
    if (SUCCEEDED(hr)) hr = s.client->GetBufferSize(&s.buffer_frames);
    REFERENCE_TIME lat = 0;
    if (SUCCEEDED(hr)) hr = s.client->GetStreamLatency(&lat);
    if (SUCCEEDED(hr)) {
        if (flow == eRender) hr = s.client->GetService(IID_PPV_ARGS(&s.render));
        else hr = s.client->GetService(IID_PPV_ARGS(&s.capture));
    }
    if (FAILED(hr)) { error = hr_text("WASAPI stream setup failed", hr); s.close(); return false; }
    // Conservative: engine-reported stream latency plus the full device buffer.
    s.latency_frames = hns_to_frames(lat, s.fmt.rate) + s.buffer_frames;
    return true;
}

class Mmcss {
public:
    Mmcss() {
        DWORD task = 0;
        handle_ = AvSetMmThreadCharacteristicsW(L"Pro Audio", &task);
        if (handle_) AvSetMmThreadPriority(handle_, AVRT_PRIORITY_CRITICAL);
    }
    ~Mmcss() { if (handle_) AvRevertMmThreadCharacteristics(handle_); }
    Mmcss(const Mmcss&) = delete;
    Mmcss& operator=(const Mmcss&) = delete;
private:
    HANDLE handle_{nullptr};
};

class ComApartment {
public:
    ComApartment() : ok_(SUCCEEDED(CoInitializeEx(nullptr, COINIT_MULTITHREADED))) {}
    ~ComApartment() { if (ok_) CoUninitialize(); }
    ComApartment(const ComApartment&) = delete;
    ComApartment& operator=(const ComApartment&) = delete;
private:
    bool ok_;
};

}  // namespace

struct WasapiBackend::Impl {
    Impl(Transport& t, const WasapiConfig& c, PeriodCallback cb, void* ctx)
        : transport(t), cfg(c), on_period(cb), context(ctx) {}

    Transport& transport;
    WasapiConfig cfg;
    PeriodCallback on_period;
    void* context;

    HANDLE shutdown{nullptr};
    HANDLE cap_ready{nullptr};
    HANDLE ren_ready{nullptr};
    std::thread cap_thread, ren_thread;
    std::atomic<bool> started{false};
    std::atomic<bool> callbacks_enabled{false};
    std::atomic<bool> cap_connected{false}, ren_connected{false};
    std::atomic<std::uint32_t> cap_latency{0}, ren_latency{0};
    std::atomic<std::uint64_t> reconnects{0};
    std::mutex warn_mutex;
    std::string cap_warning, ren_warning;
    bool timer_raised{false};

    void capture_loop() noexcept;
    void render_loop() noexcept;
};

void WasapiBackend::Impl::capture_loop() noexcept {
    ComApartment com;
    Mmcss mmcss;
    RtDenormalGuard guard;

    Stream s;
    bool open = false, first = true;
    ULONGLONG next_attempt = 0;
    std::vector<float> dev_f, map_f;
    const std::size_t asio_ch = static_cast<std::size_t>(cfg.channels);

    auto lose = [&]() {
        s.close();
        open = false;
        cap_connected.store(false, std::memory_order_release);
        next_attempt = GetTickCount64() + kReconnectIntervalMs;
    };
    auto try_open = [&]() {
        std::string err;
        if (open_stream(eCapture, cfg.sample_rate, s, err) && SUCCEEDED(s.client->Start())) {
            dev_f.assign(kCaptureChunkFrames * static_cast<std::size_t>(s.fmt.channels), 0.0F);
            map_f.assign(kCaptureChunkFrames * asio_ch, 0.0F);
            cap_latency.store(s.latency_frames, std::memory_order_relaxed);
            cap_connected.store(true, std::memory_order_release);
            open = true;
            if (!first) reconnects.fetch_add(1, std::memory_order_relaxed);
        } else {
            if (err.empty()) err = "Capture endpoint start failed";
            { std::lock_guard<std::mutex> l(warn_mutex); cap_warning = err; }
            s.close();
        }
        if (first) { first = false; SetEvent(cap_ready); }
        next_attempt = GetTickCount64() + kReconnectIntervalMs;
    };

    try_open();
    HANDLE handles[2];
    for (;;) {
        if (!open) {
            if (WaitForSingleObject(shutdown, 50) == WAIT_OBJECT_0) break;
            if (GetTickCount64() >= next_attempt) try_open();
            continue;
        }
        handles[0] = s.event;
        handles[1] = shutdown;
        const DWORD w = WaitForMultipleObjects(2, handles, FALSE, kEventTimeoutMs);
        if (w == WAIT_OBJECT_0 + 1 || w == WAIT_FAILED) break;
        UINT32 pkt = 0;
        HRESULT hr = s.capture->GetNextPacketSize(&pkt);
        if (w == WAIT_TIMEOUT) {
            if (FAILED(hr)) lose();  // stalled stream that reports an error = device gone
            continue;
        }
        while (SUCCEEDED(hr) && pkt > 0) {
            BYTE* data = nullptr;
            UINT32 frames = 0;
            DWORD flags = 0;
            hr = s.capture->GetBuffer(&data, &frames, &flags, nullptr, nullptr);
            if (FAILED(hr)) break;
            if (flags & AUDCLNT_BUFFERFLAGS_DATA_DISCONTINUITY) transport.telemetry().record_overrun();
            const std::size_t dev_ch = static_cast<std::size_t>(s.fmt.channels);
            for (UINT32 off = 0; off < frames; off += static_cast<UINT32>(kCaptureChunkFrames)) {
                const std::size_t n = std::min<std::size_t>(kCaptureChunkFrames, frames - off);
                if (flags & AUDCLNT_BUFFERFLAGS_SILENT) {
                    std::fill(map_f.begin(), map_f.begin() + static_cast<std::ptrdiff_t>(n * asio_ch), 0.0F);
                } else {
                    const BYTE* src = data + static_cast<std::size_t>(off) * static_cast<std::size_t>(s.fmt.bytes_per_frame);
                    if (!to_float(src, dev_f.data(), n * dev_ch, s.fmt.sample))
                        std::fill(dev_f.begin(), dev_f.begin() + static_cast<std::ptrdiff_t>(n * dev_ch), 0.0F);
                    map_channels(dev_f.data(), dev_ch, map_f.data(), asio_ch, n);
                }
                transport.push_capture(map_f.data(), n);
            }
            s.capture->ReleaseBuffer(frames);
            hr = s.capture->GetNextPacketSize(&pkt);
        }
        if (FAILED(hr)) lose();
    }
    s.close();
    cap_connected.store(false, std::memory_order_release);
}

void WasapiBackend::Impl::render_loop() noexcept {
    ComApartment com;
    Mmcss mmcss;
    RtDenormalGuard guard;

    Stream s;
    bool open = false, first = true;
    ULONGLONG next_attempt = 0;
    std::vector<float> asio_f, dev_f;
    const std::size_t asio_ch = static_cast<std::size_t>(cfg.channels);
    const std::size_t period = cfg.period_frames;
    asio_f.assign(period * asio_ch, 0.0F);

    // Software clock used while no render endpoint is available.
    LARGE_INTEGER qpf{};
    QueryPerformanceFrequency(&qpf);
    const double period_s = static_cast<double>(period) / static_cast<double>(cfg.sample_rate);
    LARGE_INTEGER t0{};
    QueryPerformanceCounter(&t0);
    double clock_due = 0.0;

    auto now_s = [&]() {
        LARGE_INTEGER n{};
        QueryPerformanceCounter(&n);
        return static_cast<double>(n.QuadPart - t0.QuadPart) / static_cast<double>(qpf.QuadPart);
    };
    auto lose = [&]() {
        s.close();
        open = false;
        ren_connected.store(false, std::memory_order_release);
        next_attempt = GetTickCount64() + kReconnectIntervalMs;
        clock_due = now_s();
    };
    auto try_open = [&]() {
        std::string err;
        bool good = false;
        if (open_stream(eRender, cfg.sample_rate, s, err)) {
            // Prime with silence so the engine has data before the first event.
            const UINT32 prime = std::min<UINT32>(s.buffer_frames, static_cast<UINT32>(2 * period));
            BYTE* p = nullptr;
            if (SUCCEEDED(s.render->GetBuffer(prime, &p)) &&
                SUCCEEDED(s.render->ReleaseBuffer(prime, AUDCLNT_BUFFERFLAGS_SILENT)) &&
                SUCCEEDED(s.client->Start())) {
                good = true;
            } else {
                err = "Render endpoint prime/start failed";
            }
        }
        if (good) {
            dev_f.assign(period * static_cast<std::size_t>(s.fmt.channels), 0.0F);
            ren_latency.store(s.latency_frames, std::memory_order_relaxed);
            ren_connected.store(true, std::memory_order_release);
            open = true;
            if (!first) reconnects.fetch_add(1, std::memory_order_relaxed);
        } else {
            if (err.empty()) err = "Render endpoint unavailable";
            { std::lock_guard<std::mutex> l(warn_mutex); ren_warning = err; }
            s.close();
        }
        if (first) { first = false; SetEvent(ren_ready); }
        next_attempt = GetTickCount64() + kReconnectIntervalMs;
        clock_due = now_s();
    };

    // One ASIO period: host callback (if enabled) then one period of output.
    auto run_period = [&](BYTE* device_buffer) {
        if (callbacks_enabled.load(std::memory_order_acquire)) {
            on_period(context);
            transport.pull_render(asio_f.data(), period);
        } else {
            std::fill(asio_f.begin(), asio_f.end(), 0.0F);
        }
        if (device_buffer) {
            const std::size_t dev_ch = static_cast<std::size_t>(s.fmt.channels);
            map_channels(asio_f.data(), asio_ch, dev_f.data(), dev_ch, period);
            if (!from_float(dev_f.data(), device_buffer, period * dev_ch, s.fmt.sample))
                std::memset(device_buffer, 0, period * static_cast<std::size_t>(s.fmt.bytes_per_frame));
        }
    };

    try_open();
    HANDLE handles[2];
    for (;;) {
        if (!open) {
            // Endpoint absent: keep the host callbacks flowing from a software
            // clock, discard output, and retry the endpoint periodically.
            if (WaitForSingleObject(shutdown, 1) == WAIT_OBJECT_0) break;
            const double now = now_s();
            int guardrail = 8;
            while (now >= clock_due && guardrail-- > 0) {
                run_period(nullptr);
                clock_due += period_s;
            }
            if (now > clock_due + 0.25) clock_due = now;  // do not spiral after a stall
            if (GetTickCount64() >= next_attempt) try_open();
            continue;
        }
        handles[0] = s.event;
        handles[1] = shutdown;
        const DWORD w = WaitForMultipleObjects(2, handles, FALSE, kEventTimeoutMs);
        if (w == WAIT_OBJECT_0 + 1 || w == WAIT_FAILED) break;
        UINT32 padding = 0;
        HRESULT hr = s.client->GetCurrentPadding(&padding);
        if (FAILED(hr)) { lose(); continue; }
        if (w == WAIT_TIMEOUT) continue;
        UINT32 free_frames = s.buffer_frames > padding ? s.buffer_frames - padding : 0;
        while (free_frames >= period) {
            BYTE* out = nullptr;
            hr = s.render->GetBuffer(static_cast<UINT32>(period), &out);
            if (FAILED(hr)) break;
            run_period(out);
            hr = s.render->ReleaseBuffer(static_cast<UINT32>(period), 0);
            if (FAILED(hr)) break;
            free_frames -= static_cast<UINT32>(period);
        }
        if (FAILED(hr)) lose();
    }
    s.close();
    ren_connected.store(false, std::memory_order_release);
}

WasapiBackend::WasapiBackend(Transport& transport, const WasapiConfig& config,
                             PeriodCallback on_period, void* context)
    : impl_(std::make_unique<Impl>(transport, config, on_period, context)) {}

WasapiBackend::~WasapiBackend() { stop(); }

bool WasapiBackend::start(std::string& warning) {
    Impl& d = *impl_;
    if (d.started.exchange(true)) return true;
    d.shutdown = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    d.cap_ready = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    d.ren_ready = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!d.shutdown || !d.cap_ready || !d.ren_ready) {
        warning = "CreateEvent failed";
        stop();
        return false;
    }
    if (timeBeginPeriod(1) == TIMERR_NOERROR) d.timer_raised = true;
    try {
        d.ren_thread = std::thread(&Impl::render_loop, &d);
        d.cap_thread = std::thread(&Impl::capture_loop, &d);
    } catch (...) {
        warning = "Could not start WASAPI threads";
        stop();
        return false;
    }
    HANDLE ready[2] = {d.cap_ready, d.ren_ready};
    WaitForMultipleObjects(2, ready, TRUE, kReadyTimeoutMs);
    std::lock_guard<std::mutex> l(d.warn_mutex);
    if (!d.ren_connected.load())
        warning += "Render: " + (d.ren_warning.empty() ? std::string("not ready") : d.ren_warning) + ". ";
    if (!d.cap_connected.load())
        warning += "Capture: " + (d.cap_warning.empty() ? std::string("not ready") : d.cap_warning) + ". ";
    return true;
}

void WasapiBackend::stop() noexcept {
    Impl& d = *impl_;
    d.started.store(false);
    d.callbacks_enabled.store(false, std::memory_order_release);
    if (d.shutdown) SetEvent(d.shutdown);
    if (d.ren_thread.joinable()) d.ren_thread.join();
    if (d.cap_thread.joinable()) d.cap_thread.join();
    if (d.timer_raised) { timeEndPeriod(1); d.timer_raised = false; }
    if (d.shutdown) { CloseHandle(d.shutdown); d.shutdown = nullptr; }
    if (d.cap_ready) { CloseHandle(d.cap_ready); d.cap_ready = nullptr; }
    if (d.ren_ready) { CloseHandle(d.ren_ready); d.ren_ready = nullptr; }
}

void WasapiBackend::set_callbacks_enabled(bool enabled) noexcept {
    impl_->callbacks_enabled.store(enabled, std::memory_order_release);
}
std::size_t WasapiBackend::capture_latency_frames() const noexcept { return impl_->cap_latency.load(std::memory_order_relaxed); }
std::size_t WasapiBackend::render_latency_frames() const noexcept { return impl_->ren_latency.load(std::memory_order_relaxed); }
bool WasapiBackend::capture_connected() const noexcept { return impl_->cap_connected.load(std::memory_order_acquire); }
bool WasapiBackend::render_connected() const noexcept { return impl_->ren_connected.load(std::memory_order_acquire); }
std::uint64_t WasapiBackend::reconnect_count() const noexcept { return impl_->reconnects.load(std::memory_order_relaxed); }

} // namespace crystal
