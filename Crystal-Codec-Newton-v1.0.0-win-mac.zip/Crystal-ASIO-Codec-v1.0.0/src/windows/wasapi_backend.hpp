/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/windows/wasapi_backend.hpp
 *  Purpose:    Event-driven WASAPI capture/render backend (Windows)
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#pragma once
#if !defined(_WIN32)
#error Crystal WASAPI backend is Windows-only
#endif

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

#include "crystal/transport.hpp"

namespace crystal {

struct WasapiConfig {
    int sample_rate{48000};
    int channels{2};                 // channels exchanged with Transport (ASIO side)
    std::size_t period_frames{128};  // ASIO buffer size == one host callback
};

// Event-driven shared-mode WASAPI capture + render on the default endpoints.
//
//   * The RENDER event drives the ASIO host callback: every time the render
//     endpoint has room for one ASIO period, `on_period` runs on the render
//     thread (host fills output buffers there), then one period is rendered.
//   * Capture runs on its own thread and feeds Transport::push_capture.
//   * If the render endpoint disappears, a software clock keeps the host
//     callbacks flowing (output is discarded) while the backend retries the
//     endpoint every 500 ms. Capture reconnects the same way and delivers
//     silence (via ring underrun) while it is away.
//
// COM is initialised/uninitialised per thread; both threads register with
// MMCSS ("Pro Audio") and install an RtDenormalGuard.
class WasapiBackend final {
public:
    // Called on the render thread once per ASIO period. Must not block.
    using PeriodCallback = void (*)(void* context) noexcept;

    WasapiBackend(Transport& transport, const WasapiConfig& config,
                  PeriodCallback on_period, void* context);
    ~WasapiBackend();
    WasapiBackend(const WasapiBackend&) = delete;
    WasapiBackend& operator=(const WasapiBackend&) = delete;

    // Starts both threads and waits (<= 3 s) for each endpoint's first open
    // attempt. Returns false only if threads could not be created. `warning`
    // is filled when an endpoint could not be opened (the backend keeps
    // retrying in the background).
    [[nodiscard]] bool start(std::string& warning);
    void stop() noexcept;

    // Until enabled, the render thread renders silence and never calls
    // `on_period`. Lets the driver open devices (to learn real latency) in
    // createBuffers() and begin host callbacks only in start().
    void set_callbacks_enabled(bool enabled) noexcept;

    [[nodiscard]] std::size_t capture_latency_frames() const noexcept;
    [[nodiscard]] std::size_t render_latency_frames() const noexcept;
    [[nodiscard]] bool capture_connected() const noexcept;
    [[nodiscard]] bool render_connected() const noexcept;
    [[nodiscard]] std::uint64_t reconnect_count() const noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace crystal
