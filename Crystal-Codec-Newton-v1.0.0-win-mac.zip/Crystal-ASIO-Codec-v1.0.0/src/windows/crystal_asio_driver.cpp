/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/windows/crystal_asio_driver.cpp
 *  Purpose:    Windows ASIO 2.3 COM driver wired to the WASAPI backend
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

// Crystal ASIO Codec — Windows ASIO 2.3 driver.
// Requires the separately obtained Steinberg ASIO SDK; no SDK code is vendored here.
//
// Data path:
//   WASAPI capture -> Transport (capture ring -> worker [Opus | passthrough] -> input ring)
//        -> ASIO host input buffers
//   ASIO host output buffers -> Transport (output ring) -> WASAPI render
// The WASAPI render event drives the host callback (see wasapi_backend.hpp).
#if !defined(_WIN32)
#error Crystal ASIO driver is Windows-only
#endif

#include <windows.h>
#include <objbase.h>
#include <mmreg.h>
#include <atomic>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <memory>
#include <cstdio>
#include <cstdlib>
#include <malloc.h>
#include <mutex>
#include <new>
#include <string>
#include <vector>

#include "asiosys.h"
#include "asio.h"
#include "iasiodrv.h"

#include "crystal/channel_map.hpp"
#include "crystal/config.hpp"
#include "crystal/rt_guard.hpp"
#include "crystal/telemetry.hpp"
#include "crystal/transport.hpp"
#include "crystal/version.hpp"
#include "wasapi_backend.hpp"

namespace {
// Product CLSID. Keep stable once shipped; registration uses this same GUID as IASIO IID.
// {9C4A2A1D-42E8-4B6C-9F5D-4B6A1D6A7101}
const CLSID CLSID_CrystalAsio = {0x9c4a2a1d,0x42e8,0x4b6c,{0x9f,0x5d,0x4b,0x6a,0x1d,0x6a,0x71,0x01}};
constexpr wchar_t kDriverName[] = L"Crystal ASIO Codec";
constexpr long kMinBuffer = 64;
constexpr long kMaxBuffer = 2048;
constexpr long kPreferredBuffer = 128;
constexpr long kChannelCount = 2;
std::atomic<long> g_server_locks{0};
HMODULE g_module=nullptr;
constexpr std::array<double, 5> kRates{44100.0, 48000.0, 88200.0, 96000.0, 192000.0};

bool valid_rate(double rate) noexcept {
    for (double supported : kRates) if (rate == supported) return true;
    return false;
}

std::uint64_t now_ns() noexcept {
    static const LONGLONG freq = [] { LARGE_INTEGER f{}; QueryPerformanceFrequency(&f); return f.QuadPart; }();
    LARGE_INTEGER c{};
    QueryPerformanceCounter(&c);
    return static_cast<std::uint64_t>((c.QuadPart / freq) * 1000000000LL +
                                      ((c.QuadPart % freq) * 1000000000LL) / freq);
}

// Optional per-user config: %LOCALAPPDATA%\CrystalASIOCodec\config.json
crystal::Config load_user_config() {
    crystal::Config cfg;
    wchar_t base[MAX_PATH]{};
    const DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", base, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return cfg;
    std::wstring wide = std::wstring(base) + L"\\CrystalASIOCodec\\config.json";
    const int len = WideCharToMultiByte(CP_UTF8, 0, wide.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (len <= 1) return cfg;
    std::string path(static_cast<std::size_t>(len), '\0');
    WideCharToMultiByte(CP_UTF8, 0, wide.c_str(), -1, path.data(), len, nullptr, nullptr);
    path.resize(static_cast<std::size_t>(len - 1));
    crystal::Config loaded;
    std::string err;
    if (crystal::load_config(path, loaded, err) && crystal::validate_config(loaded, err)) return loaded;
    return cfg;  // missing or invalid file -> defaults
}


// ASIOSamples / ASIOTimeStamp are hi/lo structs unless the SDK was built with
// NATIVE_INT64; set them portably.
template <typename T> void set_asio64(T& dst, std::uint64_t v) noexcept {
#if NATIVE_INT64
    dst = static_cast<T>(v);
#else
    dst.hi = static_cast<unsigned long>(v >> 32);
    dst.lo = static_cast<unsigned long>(v & 0xFFFFFFFFULL);
#endif
}

crystal::OpusMode opus_mode_for(int ms) noexcept {
    if (ms <= 5) return crystal::OpusMode::UltraLow5ms;
    if (ms >= 20) return crystal::OpusMode::Standard20ms;
    return crystal::OpusMode::Balanced10ms;
}

class CrystalAsioDriver final : public IASIO {
public:
    CrystalAsioDriver() = default;
    ~CrystalAsioDriver() { stop(); disposeBuffers(); }

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** out) override {
        if (!out) return E_POINTER;
        *out = nullptr;
        if (riid == IID_IUnknown || riid == CLSID_CrystalAsio) {
            *out = static_cast<IASIO*>(this); AddRef(); return S_OK;
        }
        return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return refs_.fetch_add(1, std::memory_order_relaxed) + 1; }
    ULONG STDMETHODCALLTYPE Release() override {
        const ULONG left = refs_.fetch_sub(1, std::memory_order_acq_rel) - 1;
        if (!left) delete this;
        return left;
    }

    ASIOBool init(void* sysHandle) override {
        sys_handle_ = sysHandle;
        user_config_ = load_user_config();
        initialized_.store(true, std::memory_order_release);
        set_error("Crystal ASIO Codec initialized");
        return ASIOTrue;
    }
    void getDriverName(char* name) override { if (name) { std::strncpy(name, "Crystal ASIO Codec", 31); name[31] = '\0'; } }
    long getDriverVersion() override { return crystal::version_major * 100 + crystal::version_minor * 10 + crystal::version_patch; }
    void getErrorMessage(char* message) override {
        if (!message) return;
        std::lock_guard<std::mutex> lock(error_mutex_);
        std::strncpy(message, error_.data(), 127); message[127] = '\0';
    }

    ASIOError start() override {
        if (!initialized_.load(std::memory_order_acquire) || !buffers_created_ || !callbacks_ || !backend_) return ASE_InvalidMode;
        if (running_.load(std::memory_order_acquire)) return ASE_OK;
        sample_counter_.store(0, std::memory_order_relaxed);
        buffer_index_.store(0, std::memory_order_relaxed);
        pos_frames_.store(0, std::memory_order_relaxed);
        pos_time_ns_.store(now_ns(), std::memory_order_relaxed);
        running_.store(true, std::memory_order_release);
        backend_->set_callbacks_enabled(true);  // render event now drives bufferSwitch
        return ASE_OK;
    }
    ASIOError stop() override {
        if (backend_) backend_->set_callbacks_enabled(false);
        running_.store(false, std::memory_order_release);
        // Wait for a callback that was already in flight to return.
        for (int i = 0; i < 2000 && in_callback_.load(std::memory_order_acquire); ++i) Sleep(1);
        return ASE_OK;
    }
    ASIOError getChannels(long* inputs, long* outputs) override {
        if (!inputs || !outputs) return ASE_InvalidParameter;
        *inputs = kChannelCount; *outputs = kChannelCount; return ASE_OK;
    }
    ASIOError getLatencies(long* input, long* output) override {
        if (!input || !output) return ASE_InvalidParameter;
        // Real depth: device latency + transport cushion (+ codec lookahead/framing when active).
        std::size_t in = static_cast<std::size_t>(buffer_size_), out = static_cast<std::size_t>(buffer_size_);
        if (transport_) {
            in = transport_->input_latency_frames();
            out = transport_->output_latency_frames();
        }
        if (backend_) { in += backend_->capture_latency_frames(); out += backend_->render_latency_frames(); }
        *input = static_cast<long>(in); *output = static_cast<long>(out); return ASE_OK;
    }
    ASIOError getBufferSize(long* minimum, long* maximum, long* preferred, long* granularity) override {
        if (!minimum || !maximum || !preferred || !granularity) return ASE_InvalidParameter;
        *minimum=kMinBuffer; *maximum=kMaxBuffer; *preferred=kPreferredBuffer; *granularity=-1; return ASE_OK;
    }
    ASIOError canSampleRate(ASIOSampleRate rate) override { return valid_rate(rate) ? ASE_OK : ASE_NoClock; }
    ASIOError getSampleRate(ASIOSampleRate* rate) override { if (!rate) return ASE_InvalidParameter; *rate=sample_rate_; return ASE_OK; }
    ASIOError setSampleRate(ASIOSampleRate rate) override {
        if (running_.load(std::memory_order_acquire)) return ASE_InvalidMode;
        if (!valid_rate(rate)) return ASE_NoClock;
        if (rate == sample_rate_) return ASE_OK;
        sample_rate_ = rate;
        if (buffers_created_ && callbacks_) {
            // Streams were opened at the old rate; ask the host to rebuild.
            if (callbacks_->asioMessage) callbacks_->asioMessage(kAsioResetRequest, 0, nullptr, nullptr);
        }
        return ASE_OK;
    }
    ASIOError getClockSources(ASIOClockSource* clocks, long* count) override {
        if (!count) return ASE_InvalidParameter;
        if (!clocks) { *count=1; return ASE_OK; }
        clocks[0].index=0; clocks[0].associatedChannel=-1; clocks[0].associatedGroup=-1;
        clocks[0].isCurrentSource=ASIOTrue; std::strncpy(clocks[0].name,"Crystal WASAPI render clock",31); clocks[0].name[31]='\0'; *count=1; return ASE_OK;
    }
    ASIOError setClockSource(long reference) override { return reference == 0 ? ASE_OK : ASE_InvalidParameter; }
    ASIOError getSamplePosition(ASIOSamples* position, ASIOTimeStamp* timestamp) override {
        if (!position || !timestamp) return ASE_InvalidParameter;
        // Position/time of the start of the buffer most recently handed to the host.
        const std::uint64_t frames = pos_frames_.load(std::memory_order_acquire);
        const std::uint64_t t = pos_time_ns_.load(std::memory_order_acquire);
        set_asio64(*position, frames);
        set_asio64(*timestamp, t);
        return ASE_OK;
    }
    ASIOError getChannelInfo(ASIOChannelInfo* info) override {
        if (!info || info->channel < 0 || info->channel >= kChannelCount) return ASE_InvalidParameter;
        info->isInput = info->isInput ? ASIOTrue : ASIOFalse;
        bool active = false;
        for (const auto& ch : buffers_) if (ch.channel == info->channel && ch.is_input == (info->isInput != 0)) active = true;
        info->isActive = active ? ASIOTrue : ASIOFalse; info->channelGroup=0; info->type=ASIOSTFloat32LSB;
        std::snprintf(info->name, sizeof(info->name), "%s %ld", info->isInput ? "Input" : "Output", info->channel+1);
        return ASE_OK;
    }
    ASIOError createBuffers(ASIOBufferInfo* infos, long channels, long size, ASIOCallbacks* callbacks) override {
        if (!initialized_.load(std::memory_order_acquire)) return ASE_NotPresent;
        if (!infos || !callbacks || channels < 1 || channels > 2*kChannelCount || size < kMinBuffer || size > kMaxBuffer) return ASE_InvalidParameter;
        if (running_.load(std::memory_order_acquire)) return ASE_InvalidMode;
        disposeBuffers();
        try {
            buffers_.resize(static_cast<std::size_t>(channels));
            for (long i=0;i<channels;++i) {
                const auto channel=infos[i].channelNum;
                if (channel < 0 || channel >= kChannelCount) { disposeBuffers(); return ASE_InvalidParameter; }
                buffers_[static_cast<std::size_t>(i)].is_input = infos[i].isInput != 0;
                buffers_[static_cast<std::size_t>(i)].channel = channel;
                for (int b=0;b<2;++b) {
                    auto* mem = static_cast<float*>(_aligned_malloc(static_cast<std::size_t>(size)*sizeof(float),64));
                    if (!mem) { disposeBuffers(); return ASE_NoMemory; }
                    std::memset(mem,0,static_cast<std::size_t>(size)*sizeof(float));
                    buffers_[static_cast<std::size_t>(i)].data[b].reset(mem);
                    infos[i].buffers[b]=mem; // Two distinct host-facing buffers per channel.
                }
            }
            io_in_.assign(static_cast<std::size_t>(size) * kChannelCount, 0.0F);
            io_out_.assign(static_cast<std::size_t>(size) * kChannelCount, 0.0F);
        } catch (...) { disposeBuffers(); return ASE_NoMemory; }
        buffer_size_=size;
        callbacks_copy_=*callbacks; callbacks_=&callbacks_copy_;

        // Build the data path. Devices open now so getLatencies() reports real depth;
        // host callbacks stay disabled until start().
        crystal::TransportConfig tc;
        tc.sample_rate = static_cast<int>(sample_rate_);
        tc.channels = static_cast<int>(kChannelCount);
        tc.asio_buffer_frames = static_cast<std::size_t>(size);
        tc.opus_enabled = user_config_.opus_enabled;
        tc.opus_mode = opus_mode_for(user_config_.opus_frame_ms);
        std::string err;
        transport_ = crystal::Transport::create(tc, err);
        std::string note;
        if (!transport_ && tc.opus_enabled) {
            // Never pretend compression happened: fall back to passthrough and say so.
            note = "Opus unavailable (" + err + "); running passthrough. ";
            tc.opus_enabled = false;
            err.clear();
            transport_ = crystal::Transport::create(tc, err);
        }
        if (!transport_) { set_error(err.c_str()); disposeBuffers(); return ASE_NoMemory; }
        if (!transport_->start(err)) { set_error(err.c_str()); disposeBuffers(); return ASE_HWMalfunction; }

        crystal::WasapiConfig wc;
        wc.sample_rate = tc.sample_rate;
        wc.channels = tc.channels;
        wc.period_frames = tc.asio_buffer_frames;
        backend_ = std::make_unique<crystal::WasapiBackend>(*transport_, wc, &CrystalAsioDriver::on_period, this);
        std::string warning;
        if (!backend_->start(warning)) { set_error(warning.c_str()); disposeBuffers(); return ASE_HWMalfunction; }
        note += warning;
        set_error(note.empty() ? "Crystal ASIO Codec ready" : note.c_str());
        buffers_created_=true;
        return ASE_OK;
    }
    ASIOError disposeBuffers() override {
        if (running_.load(std::memory_order_acquire)) return ASE_InvalidMode;
        if (backend_) backend_->set_callbacks_enabled(false);
        for (int i = 0; i < 2000 && in_callback_.load(std::memory_order_acquire); ++i) Sleep(1);
        backend_.reset();     // joins WASAPI threads first (they touch the transport)
        transport_.reset();
        buffers_.clear(); buffers_created_=false; callbacks_=nullptr; return ASE_OK;
    }
    ASIOError controlPanel() override { return ASE_NotPresent; }
    ASIOError future(long selector, void* opt) override {
        (void)opt;
        // We deliver bufferSwitchTimeInfo-style timing; everything else is unsupported.
        if (selector == kAsioCanTimeInfo) return ASE_SUCCESS;
        return ASE_NotPresent;
    }
    ASIOError outputReady() override { return ASE_OK; }  // outputs are consumed synchronously after the host callback

private:
    struct ChannelBuffers {
        bool is_input{false}; long channel{0};
        struct AlignedDelete { void operator()(float* p) const noexcept { if (p) _aligned_free(p); } };
        std::unique_ptr<float,AlignedDelete> data[2];
    };
    void set_error(const char* text) noexcept {
        std::lock_guard<std::mutex> lock(error_mutex_); std::strncpy(error_.data(),text,error_.size()-1); error_.back()='\0';
    }
    static void on_period(void* ctx) noexcept { static_cast<CrystalAsioDriver*>(ctx)->period(); }

    // Runs on the WASAPI render thread (RtDenormalGuard + MMCSS already active).
    void period() noexcept {
        if (!running_.load(std::memory_order_acquire) || !transport_ || !callbacks_) return;
        in_callback_.store(true, std::memory_order_release);
        const std::size_t n = static_cast<std::size_t>(buffer_size_);
        const long idx = static_cast<long>(buffer_index_.load(std::memory_order_relaxed) & 1U);

        float* in_planar[kChannelCount] = {nullptr, nullptr};
        const float* out_planar[kChannelCount] = {nullptr, nullptr};
        for (auto& ch : buffers_) {
            float* p = ch.data[idx].get();
            if (ch.is_input) in_planar[ch.channel] = p; else out_planar[ch.channel] = p;
        }

        // Input: ring -> host input buffers (silence on shortfall).
        (void)transport_->pull_input(io_in_.data(), n);
        crystal::deinterleave(io_in_.data(), in_planar, kChannelCount, n);

        const std::uint64_t frames = sample_counter_.load(std::memory_order_relaxed);
        const std::uint64_t t = now_ns();
        pos_frames_.store(frames, std::memory_order_release);
        pos_time_ns_.store(t, std::memory_order_release);

        if (callbacks_->bufferSwitchTimeInfo) {
            ASIOTime ti{};
            ti.timeInfo.speed = 1.0;
            set_asio64(ti.timeInfo.systemTime, t);
            set_asio64(ti.timeInfo.samplePosition, frames);
            ti.timeInfo.sampleRate = sample_rate_;
            ti.timeInfo.flags = kSystemTimeValid | kSamplePositionValid | kSampleRateValid;
            callbacks_->bufferSwitchTimeInfo(&ti, idx, ASIOFalse);
        } else if (callbacks_->bufferSwitch) {
            callbacks_->bufferSwitch(idx, ASIOFalse);
        }

        // Output: host output buffers -> ring (missing channels are silence).
        crystal::interleave(out_planar, kChannelCount, io_out_.data(), n);
        transport_->push_output(io_out_.data(), n);

        transport_->telemetry().record_switch(n);
        sample_counter_.fetch_add(static_cast<std::uint64_t>(n), std::memory_order_relaxed);
        buffer_index_.fetch_add(1, std::memory_order_relaxed);
        in_callback_.store(false, std::memory_order_release);
    }

    std::atomic<ULONG> refs_{1};
    std::atomic<bool> initialized_{false}, running_{false}, in_callback_{false};
    std::atomic<std::uint64_t> sample_counter_{0}, buffer_index_{0}, pos_frames_{0}, pos_time_ns_{0};
    double sample_rate_{48000.0}; long buffer_size_{kPreferredBuffer};
    void* sys_handle_{nullptr};
    crystal::Config user_config_{};
    std::vector<ChannelBuffers> buffers_; bool buffers_created_{false};
    std::vector<float> io_in_, io_out_;
    ASIOCallbacks callbacks_copy_{}; ASIOCallbacks* callbacks_{nullptr};
    std::unique_ptr<crystal::Transport> transport_;
    std::unique_ptr<crystal::WasapiBackend> backend_;
    std::mutex error_mutex_; std::array<char,128> error_{};
};

class CrystalClassFactory final : public IClassFactory {
public:
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** out) override {
        if (!out) return E_POINTER; *out=nullptr;
        if (riid==IID_IUnknown || riid==IID_IClassFactory) { *out=static_cast<IClassFactory*>(this); AddRef(); return S_OK; }
        return E_NOINTERFACE;
    }
    ULONG STDMETHODCALLTYPE AddRef() override { return refs_.fetch_add(1)+1; }
    ULONG STDMETHODCALLTYPE Release() override { ULONG n=refs_.fetch_sub(1)-1; if(!n) delete this; return n; }
    HRESULT STDMETHODCALLTYPE CreateInstance(IUnknown* outer, REFIID riid, void** out) override {
        if (outer) return CLASS_E_NOAGGREGATION;
        auto* driver=new(std::nothrow) CrystalAsioDriver(); if(!driver) return E_OUTOFMEMORY;
        const HRESULT hr=driver->QueryInterface(riid,out); driver->Release(); return hr;
    }
    HRESULT STDMETHODCALLTYPE LockServer(BOOL lock) override { if(lock) g_server_locks.fetch_add(1); else g_server_locks.fetch_sub(1); return S_OK; }
private: std::atomic<ULONG> refs_{1};
};
HRESULT set_registry_string(HKEY key, const wchar_t* name, const wchar_t* value) {
    return RegSetValueExW(key,name,0,REG_SZ,reinterpret_cast<const BYTE*>(value),static_cast<DWORD>((wcslen(value)+1)*sizeof(wchar_t)))==ERROR_SUCCESS ? S_OK : E_FAIL;
}
}

extern "C" BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID) {
    if (reason==DLL_PROCESS_ATTACH) { g_module=instance; DisableThreadLibraryCalls(instance); }
    return TRUE;
}
extern "C" __declspec(dllexport) HRESULT __stdcall DllGetClassObject(REFCLSID clsid, REFIID iid, void** out) {
    if (clsid!=CLSID_CrystalAsio) return CLASS_E_CLASSNOTAVAILABLE;
    auto* factory=new(std::nothrow) CrystalClassFactory(); if(!factory) return E_OUTOFMEMORY;
    const HRESULT hr=factory->QueryInterface(iid,out); factory->Release(); return hr;
}
extern "C" __declspec(dllexport) HRESULT __stdcall DllCanUnloadNow() { return g_server_locks.load()==0 ? S_OK : S_FALSE; }
extern "C" __declspec(dllexport) HRESULT __stdcall DllRegisterServer() {
    wchar_t module[MAX_PATH]{}; if(!GetModuleFileNameW(g_module,module,MAX_PATH)) return HRESULT_FROM_WIN32(GetLastError());
    wchar_t clsid[64]{}; StringFromGUID2(CLSID_CrystalAsio,clsid,64);
    HKEY key=nullptr; const wchar_t path[]=L"SOFTWARE\\ASIO\\Crystal ASIO Codec";
    if(RegCreateKeyExW(HKEY_LOCAL_MACHINE,path,0,nullptr,0,KEY_WRITE|KEY_WOW64_64KEY,nullptr,&key,nullptr)!=ERROR_SUCCESS) return HRESULT_FROM_WIN32(GetLastError());
    HRESULT hr=set_registry_string(key,L"CLSID",clsid); if(SUCCEEDED(hr)) hr=set_registry_string(key,L"Description",kDriverName); RegCloseKey(key); if(FAILED(hr)) return hr;
    wchar_t clsid_path[128]{}; swprintf_s(clsid_path,L"CLSID\\%s\\InprocServer32",clsid);
    if(RegCreateKeyExW(HKEY_CLASSES_ROOT,clsid_path,0,nullptr,0,KEY_WRITE|KEY_WOW64_64KEY,nullptr,&key,nullptr)!=ERROR_SUCCESS) return HRESULT_FROM_WIN32(GetLastError());
    hr=set_registry_string(key,nullptr,module); if(SUCCEEDED(hr)) hr=set_registry_string(key,L"ThreadingModel",L"Apartment"); RegCloseKey(key); return hr;
}
extern "C" __declspec(dllexport) HRESULT __stdcall DllUnregisterServer() {
    wchar_t clsid[64]{}; StringFromGUID2(CLSID_CrystalAsio,clsid,64);
    RegDeleteTreeW(HKEY_LOCAL_MACHINE,L"SOFTWARE\\ASIO\\Crystal ASIO Codec");
    wchar_t path[128]{}; swprintf_s(path,L"CLSID\\%s",clsid); RegDeleteTreeW(HKEY_CLASSES_ROOT,path); return S_OK;
}
