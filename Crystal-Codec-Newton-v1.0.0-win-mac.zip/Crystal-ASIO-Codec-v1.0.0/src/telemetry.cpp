/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/telemetry.cpp
 *  Purpose:    Lock-free runtime telemetry counters and snapshot reporting
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/telemetry.hpp"
#include <sstream>

namespace crystal {

void Telemetry::reset() noexcept {
    underruns_.store(0, std::memory_order_relaxed);
    overruns_.store(0, std::memory_order_relaxed);
    switches_.store(0, std::memory_order_relaxed);
    frames_.store(0, std::memory_order_relaxed);
    desyncs_.store(0, std::memory_order_relaxed);
}

TelemetrySnapshot Telemetry::snapshot() const noexcept {
    return {
        underruns_.load(std::memory_order_relaxed),
        overruns_.load(std::memory_order_relaxed),
        switches_.load(std::memory_order_relaxed),
        frames_.load(std::memory_order_relaxed),
        desyncs_.load(std::memory_order_relaxed)
    };
}

std::string Telemetry::to_json() const {
    const auto s = snapshot();
    std::ostringstream out;
    out << "{\"underruns\":" << s.underruns
        << ",\"overruns\":" << s.overruns
        << ",\"buffer_switches\":" << s.buffer_switches
        << ",\"frames\":" << s.frames
        << ",\"desyncs\":" << s.desyncs
        << "}";
    return out.str();
}

} // namespace crystal
