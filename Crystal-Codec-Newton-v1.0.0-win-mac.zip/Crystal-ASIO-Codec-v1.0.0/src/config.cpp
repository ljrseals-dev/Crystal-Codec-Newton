/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/config.cpp
 *  Purpose:    Codec configuration model, validation and loading
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/config.hpp"
#include <fstream>
#include <sstream>
namespace crystal {
bool validate_config(const Config& c, std::string& error) noexcept {
    if (c.version != 1) { error = "Unsupported config version"; return false; }
    if (c.sample_rate < 8000 || c.sample_rate > 384000) { error = "Sample rate out of range"; return false; }
    if (c.channels < 1 || c.channels > 64) { error = "Channel count out of range"; return false; }
    if (c.asio_buffer_frames < 16 || c.asio_buffer_frames > 8192) { error = "ASIO buffer size out of range"; return false; }
    if (c.opus_enabled && c.opus_frame_ms != 5 && c.opus_frame_ms != 10 && c.opus_frame_ms != 20) { error = "Opus frame must be 5, 10, or 20 ms"; return false; }
    error.clear(); return true;
}
bool save_config(const Config& c, const std::string& path, std::string& error) {
    if (!validate_config(c, error)) return false;
    std::ofstream out(path, std::ios::trunc);
    if (!out) { error = "Unable to open config for writing"; return false; }
    out << "version=" << c.version << "\nsample_rate=" << c.sample_rate << "\nchannels=" << c.channels
        << "\nasio_buffer_frames=" << c.asio_buffer_frames << "\nopus_enabled=" << c.opus_enabled
        << "\nopus_frame_ms=" << c.opus_frame_ms << "\nwasapi_exclusive=" << c.wasapi_exclusive << "\n";
    if (!out) { error = "Config write failed"; return false; }
    error.clear(); return true;
}
bool load_config(const std::string& path, Config& c, std::string& error) {
    std::ifstream in(path);
    if (!in) { error = "Unable to open config"; return false; }
    Config candidate{}; std::string line;
    while (std::getline(in, line)) {
        const auto pos = line.find('=');
        if (pos == std::string::npos) { error = "Malformed config line"; return false; }
        const auto key=line.substr(0,pos), value=line.substr(pos+1);
        try {
            if (key=="version") candidate.version=static_cast<std::uint32_t>(std::stoul(value));
            else if (key=="sample_rate") candidate.sample_rate=std::stoi(value);
            else if (key=="channels") candidate.channels=std::stoi(value);
            else if (key=="asio_buffer_frames") candidate.asio_buffer_frames=std::stoi(value);
            else if (key=="opus_enabled") candidate.opus_enabled=(std::stoi(value)!=0);
            else if (key=="opus_frame_ms") candidate.opus_frame_ms=std::stoi(value);
            else if (key=="wasapi_exclusive") candidate.wasapi_exclusive=(std::stoi(value)!=0);
            else { error = "Unknown config key: " + key; return false; }
        } catch (...) { error = "Invalid value for config key: " + key; return false; }
    }
    if (!validate_config(candidate, error)) return false;
    c=candidate; error.clear(); return true;
}
}
