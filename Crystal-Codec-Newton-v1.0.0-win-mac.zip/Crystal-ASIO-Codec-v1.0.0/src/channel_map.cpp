/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/channel_map.cpp
 *  Purpose:    Interleave/deinterleave and channel-count mapping
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/channel_map.hpp"

#include <algorithm>

namespace crystal {

void map_channels(const float* src, std::size_t src_ch,
                  float* dst, std::size_t dst_ch, std::size_t frames) noexcept {
    if (!src || !dst || src_ch == 0 || dst_ch == 0) return;
    if (src_ch == dst_ch) {
        std::copy(src, src + frames * src_ch, dst);
        return;
    }
    if (src_ch == 1) {
        for (std::size_t i = 0; i < frames; ++i)
            for (std::size_t c = 0; c < dst_ch; ++c) dst[i * dst_ch + c] = src[i];
        return;
    }
    if (dst_ch == 1) {
        const float inv = 1.0F / static_cast<float>(src_ch);
        for (std::size_t i = 0; i < frames; ++i) {
            float sum = 0.0F;
            for (std::size_t c = 0; c < src_ch; ++c) sum += src[i * src_ch + c];
            dst[i] = sum * inv;
        }
        return;
    }
    const std::size_t common = std::min(src_ch, dst_ch);
    for (std::size_t i = 0; i < frames; ++i) {
        for (std::size_t c = 0; c < common; ++c) dst[i * dst_ch + c] = src[i * src_ch + c];
        for (std::size_t c = common; c < dst_ch; ++c) dst[i * dst_ch + c] = 0.0F;
    }
}

void interleave(const float* const* planar, std::size_t channels,
                float* out, std::size_t frames) noexcept {
    if (!planar || !out) return;
    for (std::size_t c = 0; c < channels; ++c) {
        const float* p = planar[c];
        for (std::size_t i = 0; i < frames; ++i) out[i * channels + c] = p ? p[i] : 0.0F;
    }
}

void deinterleave(const float* in, float* const* planar, std::size_t channels,
                  std::size_t frames) noexcept {
    if (!planar || !in) return;
    for (std::size_t c = 0; c < channels; ++c) {
        float* p = planar[c];
        if (!p) continue;
        for (std::size_t i = 0; i < frames; ++i) p[i] = in[i * channels + c];
    }
}

} // namespace crystal
