/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/rt_guard.cpp
 *  Purpose:    Real-time audio-thread denormal (FTZ/DAZ) guard
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/rt_guard.hpp"

#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
  #include <xmmintrin.h>
  #include <pmmintrin.h>
  #define CRYSTAL_X86 1
#elif (defined(__x86_64__) || defined(__i386__)) && (defined(__GNUC__) || defined(__clang__))
  #include <xmmintrin.h>
  #include <pmmintrin.h>
  #define CRYSTAL_X86 1
#endif

#if defined(__aarch64__) && (defined(__GNUC__) || defined(__clang__))
  #define CRYSTAL_ARM64 1
#endif

namespace crystal {

RtDenormalGuard::RtDenormalGuard() noexcept {
#if defined(CRYSTAL_X86)
    saved_ = _mm_getcsr();
    // Bit 15 = FTZ, bit 6 = DAZ.
    _mm_setcsr(saved_ | 0x8040U);
    active_ = true;
#elif defined(CRYSTAL_ARM64)
    // FPCR.FZ (bit 24) flushes denormals.
    std::uint64_t fpcr = 0;
    __asm__ __volatile__("mrs %0, fpcr" : "=r"(fpcr));
    saved_fpcr_ = fpcr;
    __asm__ __volatile__("msr fpcr, %0" :: "r"(fpcr | (1ULL << 24)));
    active_ = true;
#endif
}

RtDenormalGuard::~RtDenormalGuard() noexcept {
#if defined(CRYSTAL_X86)
    if (active_) _mm_setcsr(saved_);
#elif defined(CRYSTAL_ARM64)
    if (active_) {
        __asm__ __volatile__("msr fpcr, %0" :: "r"(saved_fpcr_));
    }
#endif
}

bool RtDenormalGuard::current_thread_has_flush() noexcept {
#if defined(CRYSTAL_X86)
    return (_mm_getcsr() & 0x8040U) == 0x8040U;
#elif defined(CRYSTAL_ARM64)
    std::uint64_t fpcr = 0;
    __asm__ __volatile__("mrs %0, fpcr" : "=r"(fpcr));
    return (fpcr & (1ULL << 24)) != 0;
#else
    return false;
#endif
}

} // namespace crystal
