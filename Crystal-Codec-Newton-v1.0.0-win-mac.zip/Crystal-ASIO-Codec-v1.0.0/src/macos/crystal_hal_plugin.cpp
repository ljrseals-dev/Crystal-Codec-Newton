/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/macos/crystal_hal_plugin.cpp
 *  Purpose:    macOS Core Audio (AudioServerPlugIn) virtual device wired to the Transport
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

// Crystal Codec - Newton for macOS: Core Audio AudioServerPlugIn (HAL) driver.
//
// macOS has no ASIO. Core Audio is the native low-latency path, so this is a
// virtual audio device built ONLY on Apple's public AudioServerPlugIn API and
// the project's own portable core. No Steinberg SDK, headers or code are used.
//
//   apps -> "Crystal Codec" OUTPUT stream -> WriteMix -> Transport
//        -> worker (bit-transparent passthrough, or Opus if built in)
//        -> ReadInput -> "Crystal Codec" INPUT stream -> apps
//
// Quality defaults: float32 interleaved stereo, 44.1-192 kHz, the same format
// virtual and physical (no internal conversion or resampling). The default
// path is bit-exact. Opus is lossy by design and is compile-time opt-in.
#include <CoreAudio/AudioServerPlugIn.h>
#include <CoreFoundation/CoreFoundation.h>
#include <CoreFoundation/CFPlugInCOM.h>
#include <mach/mach_time.h>

#include <atomic>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>

#include "crystal/rt_guard.hpp"
#include "crystal/transport.hpp"
#include "crystal/version.hpp"

extern AudioServerPlugInDriverRef gDriverRef;

namespace {

constexpr AudioObjectID kObjPlugIn = kAudioObjectPlugInObject;
constexpr AudioObjectID kObjDevice = 2;
constexpr AudioObjectID kObjStreamIn = 3;   // device -> apps (input)
constexpr AudioObjectID kObjStreamOut = 4;  // apps -> device (output)
constexpr UInt32 kChannels = 2;
constexpr UInt32 kZeroTimeStampPeriod = 16384;
constexpr UInt32 kIoFrames = 512;  // transport sizing; HAL cycle sizes may differ
constexpr Float64 kRates[] = {44100.0, 48000.0, 88200.0, 96000.0, 176400.0, 192000.0};

#define CRYSTAL_UID "CrystalCodecNewton:Device:1"

struct State {
    std::atomic<UInt32> refs{1};
    AudioServerPlugInHostRef host{nullptr};
    std::mutex mu;
    Float64 rate{48000.0};
    UInt32 io_count{0};
    UInt64 anchor{0};
    Float64 ticks_per_frame{0.0};
    bool active_in{true}, active_out{true};
    std::unique_ptr<crystal::Transport> transport;
    std::atomic<crystal::Transport*> live{nullptr};
};
State g;

bool rate_ok(Float64 r) {
    for (Float64 s : kRates) if (s == r) return true;
    return false;
}

AudioStreamBasicDescription make_format(Float64 rate) {
    AudioStreamBasicDescription f{};
    f.mSampleRate = rate;
    f.mFormatID = kAudioFormatLinearPCM;
    f.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagsNativeEndian | kAudioFormatFlagIsPacked;
    f.mBytesPerPacket = kChannels * sizeof(float);
    f.mFramesPerPacket = 1;
    f.mBytesPerFrame = kChannels * sizeof(float);
    f.mChannelsPerFrame = kChannels;
    f.mBitsPerChannel = 32;
    return f;
}

// ---- property plumbing ------------------------------------------------------
struct Out {
    UInt32 in_size;
    UInt32* out_size;
    void* data;
    bool size_only;
    OSStatus status{kAudioHardwareNoError};

    template <typename T> void put(const T& v) { put_array(&v, 1); }
    template <typename T> void put_array(const T* v, UInt32 n) {
        const UInt32 bytes = n * static_cast<UInt32>(sizeof(T));
        if (size_only) { *out_size = bytes; return; }
        const UInt32 fit = in_size / static_cast<UInt32>(sizeof(T));
        const UInt32 cnt = n < fit ? n : fit;
        if (cnt == 0 && n != 0) { status = kAudioHardwareBadPropertySizeError; return; }
        if (cnt) std::memcpy(data, v, cnt * sizeof(T));
        *out_size = cnt * static_cast<UInt32>(sizeof(T));
    }
    void put_string(const char* s) {
        CFStringRef str = CFStringCreateWithCString(nullptr, s, kCFStringEncodingUTF8);
        if (size_only) { *out_size = sizeof(CFStringRef); CFRelease(str); return; }
        if (in_size < sizeof(CFStringRef)) { CFRelease(str); status = kAudioHardwareBadPropertySizeError; return; }
        *static_cast<CFStringRef*>(data) = str;  // caller releases
        *out_size = sizeof(CFStringRef);
    }
};

OSStatus get_prop(AudioObjectID obj, const AudioObjectPropertyAddress* a, UInt32 in_size,
                  UInt32* out_size, void* data, bool size_only) {
    Out o{in_size, out_size, data, size_only};
    const AudioObjectPropertySelector sel = a->mSelector;
    const AudioObjectPropertyScope scope = a->mScope;
    bool found = true;

    if (obj == kObjPlugIn) {
        switch (sel) {
            case kAudioObjectPropertyBaseClass: o.put<AudioClassID>(kAudioObjectClassID); break;
            case kAudioObjectPropertyClass: o.put<AudioClassID>(kAudioPlugInClassID); break;
            case kAudioObjectPropertyOwner: o.put<AudioObjectID>(kAudioObjectUnknown); break;
            case kAudioObjectPropertyManufacturer: o.put_string("UnderJive-Records-Turnkey"); break;
            case kAudioObjectPropertyOwnedObjects:
            case kAudioPlugInPropertyDeviceList: { AudioObjectID d = kObjDevice; o.put_array(&d, 1); break; }
            case kAudioPlugInPropertyTranslateUIDToDevice: {
                if (in_size < sizeof(AudioObjectID) && !size_only) return kAudioHardwareBadPropertySizeError;
                o.put<AudioObjectID>(kObjDevice); break;
            }
            case kAudioPlugInPropertyResourceBundle: o.put_string(""); break;
            default: found = false;
        }
    } else if (obj == kObjDevice) {
        switch (sel) {
            case kAudioObjectPropertyBaseClass: o.put<AudioClassID>(kAudioObjectClassID); break;
            case kAudioObjectPropertyClass: o.put<AudioClassID>(kAudioDeviceClassID); break;
            case kAudioObjectPropertyOwner: o.put<AudioObjectID>(kObjPlugIn); break;
            case kAudioObjectPropertyName: o.put_string("Crystal Codec - Newton"); break;
            case kAudioObjectPropertyManufacturer: o.put_string("UnderJive-Records-Turnkey"); break;
            case kAudioObjectPropertyOwnedObjects: {
                AudioObjectID s[2] = {kObjStreamIn, kObjStreamOut};
                if (scope == kAudioObjectPropertyScopeInput) o.put_array(&s[0], 1);
                else if (scope == kAudioObjectPropertyScopeOutput) o.put_array(&s[1], 1);
                else o.put_array(s, 2);
                break;
            }
            case kAudioDevicePropertyStreams: {
                AudioObjectID s[2] = {kObjStreamIn, kObjStreamOut};
                if (scope == kAudioObjectPropertyScopeInput) o.put_array(&s[0], 1);
                else if (scope == kAudioObjectPropertyScopeOutput) o.put_array(&s[1], 1);
                else o.put_array(s, 2);
                break;
            }
            case kAudioObjectPropertyControlList: { AudioObjectID none = 0; o.put_array(&none, 0); break; }
            case kAudioDevicePropertyDeviceUID: o.put_string(CRYSTAL_UID); break;
            case kAudioDevicePropertyModelUID: o.put_string("CrystalCodecNewton:Model"); break;
            case kAudioDevicePropertyTransportType: o.put<UInt32>(kAudioDeviceTransportTypeVirtual); break;
            case kAudioDevicePropertyRelatedDevices: { AudioObjectID d = kObjDevice; o.put_array(&d, 1); break; }
            case kAudioDevicePropertyClockDomain: o.put<UInt32>(0); break;
            case kAudioDevicePropertyDeviceIsAlive: o.put<UInt32>(1); break;
            case kAudioDevicePropertyDeviceIsRunning: { std::lock_guard<std::mutex> l(g.mu); o.put<UInt32>(g.io_count > 0 ? 1 : 0); break; }
            case kAudioDevicePropertyDeviceCanBeDefaultDevice:
            case kAudioDevicePropertyDeviceCanBeDefaultSystemDevice: o.put<UInt32>(1); break;
            case kAudioDevicePropertyLatency: o.put<UInt32>(0); break;
            case kAudioDevicePropertySafetyOffset: o.put<UInt32>(0); break;
            case kAudioDevicePropertyNominalSampleRate: { std::lock_guard<std::mutex> l(g.mu); o.put<Float64>(g.rate); break; }
            case kAudioDevicePropertyAvailableNominalSampleRates: {
                AudioValueRange r[sizeof(kRates) / sizeof(kRates[0])];
                for (size_t i = 0; i < sizeof(kRates) / sizeof(kRates[0]); ++i) r[i] = {kRates[i], kRates[i]};
                o.put_array(r, sizeof(kRates) / sizeof(kRates[0]));
                break;
            }
            case kAudioDevicePropertyIsHidden: o.put<UInt32>(0); break;
            case kAudioDevicePropertyZeroTimeStampPeriod: o.put<UInt32>(kZeroTimeStampPeriod); break;
            case kAudioDevicePropertyPreferredChannelsForStereo: { UInt32 ch[2] = {1, 2}; o.put_array(ch, 2); break; }
            default: found = false;
        }
    } else if (obj == kObjStreamIn || obj == kObjStreamOut) {
        const bool is_input = obj == kObjStreamIn;
        switch (sel) {
            case kAudioObjectPropertyBaseClass: o.put<AudioClassID>(kAudioObjectClassID); break;
            case kAudioObjectPropertyClass: o.put<AudioClassID>(kAudioStreamClassID); break;
            case kAudioObjectPropertyOwner: o.put<AudioObjectID>(kObjDevice); break;
            case kAudioObjectPropertyOwnedObjects: { AudioObjectID none = 0; o.put_array(&none, 0); break; }
            case kAudioStreamPropertyIsActive: { std::lock_guard<std::mutex> l(g.mu); o.put<UInt32>((is_input ? g.active_in : g.active_out) ? 1 : 0); break; }
            case kAudioStreamPropertyDirection: o.put<UInt32>(is_input ? 1 : 0); break;
            case kAudioStreamPropertyTerminalType:
                o.put<UInt32>(is_input ? kAudioStreamTerminalTypeMicrophone : kAudioStreamTerminalTypeSpeaker); break;
            case kAudioStreamPropertyStartingChannel: o.put<UInt32>(1); break;
            case kAudioStreamPropertyLatency: o.put<UInt32>(0); break;
            case kAudioStreamPropertyVirtualFormat:
            case kAudioStreamPropertyPhysicalFormat: {
                std::lock_guard<std::mutex> l(g.mu);
                o.put<AudioStreamBasicDescription>(make_format(g.rate));
                break;
            }
            case kAudioStreamPropertyAvailableVirtualFormats:
            case kAudioStreamPropertyAvailablePhysicalFormats: {
                AudioStreamRangedDescription r[sizeof(kRates) / sizeof(kRates[0])];
                for (size_t i = 0; i < sizeof(kRates) / sizeof(kRates[0]); ++i) {
                    r[i].mFormat = make_format(kRates[i]);
                    r[i].mSampleRateRange = {kRates[i], kRates[i]};
                }
                o.put_array(r, sizeof(kRates) / sizeof(kRates[0]));
                break;
            }
            default: found = false;
        }
    } else {
        return kAudioHardwareBadObjectError;
    }
    if (!found) return kAudioHardwareUnknownPropertyError;
    return o.status;
}

// ---- driver interface ---------------------------------------------------------
HRESULT QueryInterface(void*, REFIID uuid, LPVOID* out) {
    if (!out) return E_POINTER;
    CFUUIDRef req = CFUUIDCreateFromUUIDBytes(nullptr, uuid);
    CFUUIDRef iface = kAudioServerPlugInDriverInterfaceUUID;
    const bool ok = CFEqual(req, IUnknownUUID) || CFEqual(req, iface);
    CFRelease(req);
    if (!ok) { *out = nullptr; return E_NOINTERFACE; }
    g.refs.fetch_add(1);
    *out = gDriverRef;
    return S_OK;
}
ULONG AddRef(void*) { return g.refs.fetch_add(1) + 1; }
ULONG Release(void*) { return g.refs.fetch_sub(1) - 1; }

OSStatus Initialize(AudioServerPlugInDriverRef, AudioServerPlugInHostRef host) { g.host = host; return kAudioHardwareNoError; }
OSStatus CreateDevice(AudioServerPlugInDriverRef, CFDictionaryRef, const AudioServerPlugInClientInfo*, AudioObjectID*) { return kAudioHardwareUnsupportedOperationError; }
OSStatus DestroyDevice(AudioServerPlugInDriverRef, AudioObjectID) { return kAudioHardwareUnsupportedOperationError; }
OSStatus AddDeviceClient(AudioServerPlugInDriverRef, AudioObjectID, const AudioServerPlugInClientInfo*) { return kAudioHardwareNoError; }
OSStatus RemoveDeviceClient(AudioServerPlugInDriverRef, AudioObjectID, const AudioServerPlugInClientInfo*) { return kAudioHardwareNoError; }

OSStatus PerformDeviceConfigurationChange(AudioServerPlugInDriverRef, AudioObjectID dev, UInt64 action, void*) {
    if (dev != kObjDevice) return kAudioHardwareBadObjectError;
    std::lock_guard<std::mutex> l(g.mu);
    g.rate = static_cast<Float64>(action);  // action carries the new rate in Hz
    return kAudioHardwareNoError;
}
OSStatus AbortDeviceConfigurationChange(AudioServerPlugInDriverRef, AudioObjectID, UInt64, void*) { return kAudioHardwareNoError; }

Boolean HasProperty(AudioServerPlugInDriverRef, AudioObjectID obj, pid_t, const AudioObjectPropertyAddress* a) {
    UInt32 sz = 0;
    return get_prop(obj, a, 0, &sz, nullptr, true) == kAudioHardwareNoError;
}
OSStatus IsPropertySettable(AudioServerPlugInDriverRef, AudioObjectID obj, pid_t, const AudioObjectPropertyAddress* a, Boolean* settable) {
    UInt32 sz = 0;
    const OSStatus st = get_prop(obj, a, 0, &sz, nullptr, true);
    if (st != kAudioHardwareNoError) return st;
    *settable = (obj == kObjDevice && a->mSelector == kAudioDevicePropertyNominalSampleRate) ||
                ((obj == kObjStreamIn || obj == kObjStreamOut) &&
                 (a->mSelector == kAudioStreamPropertyIsActive ||
                  a->mSelector == kAudioStreamPropertyVirtualFormat ||
                  a->mSelector == kAudioStreamPropertyPhysicalFormat));
    return kAudioHardwareNoError;
}
OSStatus GetPropertyDataSize(AudioServerPlugInDriverRef, AudioObjectID obj, pid_t, const AudioObjectPropertyAddress* a, UInt32, const void*, UInt32* size) {
    return get_prop(obj, a, 0, size, nullptr, true);
}
OSStatus GetPropertyData(AudioServerPlugInDriverRef, AudioObjectID obj, pid_t, const AudioObjectPropertyAddress* a, UInt32, const void*, UInt32 in_size, UInt32* out_size, void* data) {
    return get_prop(obj, a, in_size, out_size, data, false);
}

OSStatus request_rate(Float64 rate) {
    if (!rate_ok(rate)) return kAudioDeviceUnsupportedFormatError;
    { std::lock_guard<std::mutex> l(g.mu); if (rate == g.rate) return kAudioHardwareNoError; }
    if (g.host) g.host->RequestDeviceConfigurationChange(g.host, kObjDevice, static_cast<UInt64>(rate), nullptr);
    return kAudioHardwareNoError;
}
OSStatus SetPropertyData(AudioServerPlugInDriverRef, AudioObjectID obj, pid_t, const AudioObjectPropertyAddress* a, UInt32, const void*, UInt32 size, const void* data) {
    if (obj == kObjDevice && a->mSelector == kAudioDevicePropertyNominalSampleRate) {
        if (size != sizeof(Float64)) return kAudioHardwareBadPropertySizeError;
        return request_rate(*static_cast<const Float64*>(data));
    }
    if ((obj == kObjStreamIn || obj == kObjStreamOut)) {
        if (a->mSelector == kAudioStreamPropertyIsActive) {
            if (size != sizeof(UInt32)) return kAudioHardwareBadPropertySizeError;
            std::lock_guard<std::mutex> l(g.mu);
            (obj == kObjStreamIn ? g.active_in : g.active_out) = *static_cast<const UInt32*>(data) != 0;
            return kAudioHardwareNoError;
        }
        if (a->mSelector == kAudioStreamPropertyVirtualFormat || a->mSelector == kAudioStreamPropertyPhysicalFormat) {
            if (size != sizeof(AudioStreamBasicDescription)) return kAudioHardwareBadPropertySizeError;
            const auto* f = static_cast<const AudioStreamBasicDescription*>(data);
            if (f->mFormatID != kAudioFormatLinearPCM || f->mChannelsPerFrame != kChannels ||
                f->mBitsPerChannel != 32 || !(f->mFormatFlags & kAudioFormatFlagIsFloat))
                return kAudioDeviceUnsupportedFormatError;
            return request_rate(f->mSampleRate);
        }
    }
    return kAudioHardwareUnknownPropertyError;
}

OSStatus StartIO(AudioServerPlugInDriverRef, AudioObjectID dev, UInt32) {
    if (dev != kObjDevice) return kAudioHardwareBadObjectError;
    std::lock_guard<std::mutex> l(g.mu);
    if (g.io_count == 0) {
        crystal::TransportConfig tc;
        tc.sample_rate = static_cast<int>(g.rate);
        tc.channels = static_cast<int>(kChannels);
        tc.asio_buffer_frames = kIoFrames;
#ifdef CRYSTAL_MAC_CODEC_OPUS
        tc.opus_enabled = true;
#endif
        std::string err;
        auto t = crystal::Transport::create(tc, err);
        if (!t) return kAudioHardwareUnspecifiedError;
        t->prime_input(kIoFrames);  // deterministic cushion against worker jitter
        if (!t->start(err)) return kAudioHardwareUnspecifiedError;
        mach_timebase_info_data_t tb{};
        mach_timebase_info(&tb);
        const Float64 ticks_per_sec = 1.0e9 * static_cast<Float64>(tb.denom) / static_cast<Float64>(tb.numer);
        g.ticks_per_frame = ticks_per_sec / g.rate;
        g.anchor = mach_absolute_time();
        g.transport = std::move(t);
        g.live.store(g.transport.get(), std::memory_order_release);
    }
    ++g.io_count;
    return kAudioHardwareNoError;
}
OSStatus StopIO(AudioServerPlugInDriverRef, AudioObjectID dev, UInt32) {
    if (dev != kObjDevice) return kAudioHardwareBadObjectError;
    std::lock_guard<std::mutex> l(g.mu);
    if (g.io_count > 0 && --g.io_count == 0) {
        g.live.store(nullptr, std::memory_order_release);
        g.transport.reset();  // joins the worker; HAL guarantees no IO after StopIO
    }
    return kAudioHardwareNoError;
}
OSStatus GetZeroTimeStamp(AudioServerPlugInDriverRef, AudioObjectID, UInt32, Float64* sample_time, UInt64* host_time, UInt64* seed) {
    const Float64 ticks_per_period = g.ticks_per_frame * static_cast<Float64>(kZeroTimeStampPeriod);
    const UInt64 now = mach_absolute_time();
    const UInt64 n = ticks_per_period > 0 ? static_cast<UInt64>(static_cast<Float64>(now - g.anchor) / ticks_per_period) : 0;
    *sample_time = static_cast<Float64>(n * kZeroTimeStampPeriod);
    *host_time = g.anchor + static_cast<UInt64>(static_cast<Float64>(n) * ticks_per_period);
    *seed = 1;
    return kAudioHardwareNoError;
}
OSStatus WillDoIOOperation(AudioServerPlugInDriverRef, AudioObjectID, UInt32, UInt32 op, Boolean* will, Boolean* in_place) {
    *will = (op == kAudioServerPlugInIOOperationReadInput || op == kAudioServerPlugInIOOperationWriteMix);
    *in_place = true;
    return kAudioHardwareNoError;
}
OSStatus BeginIOOperation(AudioServerPlugInDriverRef, AudioObjectID, UInt32, UInt32, UInt32, const AudioServerPlugInIOCycleInfo*) { return kAudioHardwareNoError; }
OSStatus EndIOOperation(AudioServerPlugInDriverRef, AudioObjectID, UInt32, UInt32, UInt32, const AudioServerPlugInIOCycleInfo*) { return kAudioHardwareNoError; }

OSStatus DoIOOperation(AudioServerPlugInDriverRef, AudioObjectID, AudioObjectID stream, UInt32, UInt32 op,
                       UInt32 frames, const AudioServerPlugInIOCycleInfo*, void* main_buf, void*) {
    crystal::RtDenormalGuard guard;
    crystal::Transport* t = g.live.load(std::memory_order_acquire);
    float* buf = static_cast<float*>(main_buf);
    if (op == kAudioServerPlugInIOOperationReadInput) {
        if (t && stream == kObjStreamIn) (void)t->pull_input(buf, frames);
        else std::memset(buf, 0, static_cast<size_t>(frames) * kChannels * sizeof(float));
    } else if (op == kAudioServerPlugInIOOperationWriteMix) {
        if (t && stream == kObjStreamOut) t->push_capture(buf, frames);
    }
    return kAudioHardwareNoError;
}

AudioServerPlugInDriverInterface gInterface = {
    nullptr, QueryInterface, AddRef, Release, Initialize, CreateDevice, DestroyDevice,
    AddDeviceClient, RemoveDeviceClient, PerformDeviceConfigurationChange,
    AbortDeviceConfigurationChange, HasProperty, IsPropertySettable, GetPropertyDataSize,
    GetPropertyData, SetPropertyData, StartIO, StopIO, GetZeroTimeStamp, WillDoIOOperation,
    BeginIOOperation, DoIOOperation, EndIOOperation};
AudioServerPlugInDriverInterface* gInterfacePtr = &gInterface;

}  // namespace

AudioServerPlugInDriverRef gDriverRef = &gInterfacePtr;

extern "C" __attribute__((visibility("default")))
void* CrystalCodecPlugInFactory(CFAllocatorRef, CFUUIDRef requested_type) {
    if (!CFEqual(requested_type, kAudioServerPlugInTypeUUID)) return nullptr;
    return gDriverRef;
}
