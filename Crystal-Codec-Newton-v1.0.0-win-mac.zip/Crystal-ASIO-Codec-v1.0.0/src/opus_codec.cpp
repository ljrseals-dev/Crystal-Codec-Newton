/*
 * ======================================================================
 *  Crystal Codec - Newton
 *  Crystal ASIO Codec v1.0.0
 * ----------------------------------------------------------------------
 *  File:       src/opus_codec.cpp
 *  Purpose:    Opus encode/decode wrapper with passthrough fallback
 *
 *  Project:    Crystal City
 *  Authors:    Crystal Cheairs and Rev. Cheairs
 *  Developer:  Lewis J. Seals Jr. (Therealla) - ljrseals-dev
 *  Owner:      UnderJive-Records-Turnkey
 *  License:    MIT (see LICENSE)
 * ======================================================================
 */

#include "crystal/opus_codec.hpp"
#include <algorithm>
#include <new>

#ifdef CRYSTAL_HAVE_OPUS
#include <opus/opus.h>
#endif

namespace crystal {

struct OpusCodec::Impl {
#ifdef CRYSTAL_HAVE_OPUS
    OpusEncoder* encoder{nullptr};
    OpusDecoder* decoder{nullptr};
#endif
};

OpusCodec::OpusCodec(const OpusConfig& c) : impl_(std::make_unique<Impl>()), config_(c) {
    const int ms = c.mode == OpusMode::UltraLow5ms ? 5
                 : (c.mode == OpusMode::Balanced10ms ? 10 : 20);
    frame_size_ = static_cast<std::size_t>(c.sample_rate * ms / 1000);
    margin_frames_ = static_cast<std::size_t>(c.sample_rate / 1000);
}

OpusCodec::~OpusCodec() {
#ifdef CRYSTAL_HAVE_OPUS
    if (impl_) {
        if (impl_->encoder) opus_encoder_destroy(impl_->encoder);
        if (impl_->decoder) opus_decoder_destroy(impl_->decoder);
    }
#endif
}

std::unique_ptr<OpusCodec> OpusCodec::create(const OpusConfig& c, std::string& error) {
    error.clear();
    if ((c.sample_rate != 8000 && c.sample_rate != 12000 &&
         c.sample_rate != 16000 && c.sample_rate != 24000 &&
         c.sample_rate != 48000) ||
        (c.channels != 1 && c.channels != 2) ||
        c.complexity < 0 || c.complexity > 10) {
        error = "Invalid Opus configuration (supported rates: 8/12/16/24/48 kHz; "
                "channels: 1/2; complexity: 0..10)";
        return nullptr;
    }
#ifndef CRYSTAL_HAVE_OPUS
    error = "Crystal was built without libopus; install libopus and "
            "configure with CRYSTAL_ENABLE_OPUS=ON";
    return nullptr;
#else
    auto codec = std::unique_ptr<OpusCodec>(new OpusCodec(c));
    int err = OPUS_OK;
    codec->impl_->encoder = opus_encoder_create(c.sample_rate, c.channels,
                                                OPUS_APPLICATION_AUDIO, &err);
    if (!codec->impl_->encoder || err != OPUS_OK) {
        error = "opus_encoder_create failed";
        return nullptr;
    }
    opus_encoder_ctl(codec->impl_->encoder, OPUS_SET_COMPLEXITY(c.complexity));
    opus_encoder_ctl(codec->impl_->encoder, OPUS_SET_VBR(c.vbr ? 1 : 0));
    codec->impl_->decoder = opus_decoder_create(c.sample_rate, c.channels, &err);
    if (!codec->impl_->decoder || err != OPUS_OK) {
        error = "opus_decoder_create failed";
        return nullptr;
    }
    opus_int32 lookahead = 0;
    if (opus_encoder_ctl(codec->impl_->encoder, OPUS_GET_LOOKAHEAD(&lookahead))
            == OPUS_OK && lookahead > 0) {
        codec->lookahead_frames_ = static_cast<std::size_t>(lookahead);
    }
    return codec;
#endif
}

int OpusCodec::encode(const float* pcm, int frames,
                      unsigned char* packet, int capacity) noexcept {
#ifdef CRYSTAL_HAVE_OPUS
    if (!impl_ || !impl_->encoder) return -1;
    if (pcm == nullptr || packet == nullptr) return -1;
    if (capacity < 0 || capacity > kMaxOpusPacketBytes) return -1;
    if (frames != static_cast<int>(frame_size_)) return -1;
    return opus_encode_float(impl_->encoder, pcm, frames, packet, capacity);
#else
    (void)pcm; (void)frames; (void)packet; (void)capacity; return -1;
#endif
}

int OpusCodec::decode(const unsigned char* packet, int packet_bytes,
                      float* pcm, int max_frames) noexcept {
#ifdef CRYSTAL_HAVE_OPUS
    if (!impl_ || !impl_->decoder || pcm == nullptr) return -1;

    // Reject undersized output buffers BEFORE the decoder writes anything.
    // This is the exact failure mode of CVE-2026-45515 (Android A2DP Opus):
    // a caller passing samples-per-channel confusion or a small buffer.
    if (max_frames < static_cast<int>(frame_size_)) return -1;

    // `packet` may be null only for packet-loss concealment (PLC), which
    // requires packet_bytes == 0. Any nonzero length with a null pointer is
    // a caller bug and must be rejected before libopus dereferences it.
    if (packet == nullptr && packet_bytes != 0) return -1;
    if (packet_bytes < 0 || packet_bytes > kMaxOpusPacketBytes) return -1;

    return opus_decode_float(impl_->decoder, packet, packet_bytes, pcm, max_frames, 0);
#else
    (void)packet; (void)packet_bytes; (void)pcm; (void)max_frames; return -1;
#endif
}

void OpusCodec::reset() noexcept {
#ifdef CRYSTAL_HAVE_OPUS
    if (impl_ && impl_->encoder) opus_encoder_ctl(impl_->encoder, OPUS_RESET_STATE);
    if (impl_ && impl_->decoder) opus_decoder_ctl(impl_->decoder, OPUS_RESET_STATE);
#endif
}

} // namespace crystal
