# Windows ASIO driver — integration and status

The driver (`src/windows/crystal_asio_driver.cpp`) consumes the Steinberg ASIO SDK
headers from a local checkout (`ASIO_SDK_ROOT`, containing `common/asiosys.h`,
`common/asio.h`, `common/iasiodrv.h`). No SDK source is redistributed.

## Data path (implemented)

```
WASAPI capture (own thread, event-driven)
   -> Transport capture ring -> worker (Opus encode/decode | passthrough)
   -> Transport input ring -> ASIO host input buffers

ASIO host output buffers -> Transport output ring
   -> WASAPI render (render EVENT drives the ASIO host callback)
```

- **Callback timing:** the render event fires `bufferSwitchTimeInfo`/`bufferSwitch`
  once per ASIO period on the render thread (MMCSS "Pro Audio", FTZ/DAZ guard).
  The old synthetic waitable-timer clock is gone. It survives only as a fallback
  while no render endpoint exists, so host callbacks do not stall on unplug.
- **Endpoints:** default capture/render, shared mode. Opening tries, in order:
  IAudioClient3 low-latency stream (when engine rate == ASIO rate); float32
  stereo with Windows format + sample-rate conversion; engine mix format with
  manual conversion. Manual conversion classifies the real
  `WAVEFORMATEX(TENSIBLE)` subformat (PCM16/24/32, float32) and maps channels.
- **Disconnect/reconnect:** a lost stream is closed and the endpoint retried every
  500 ms; capture delivers silence meanwhile; reconnects are counted.
- **Drift:** the capture and render clocks are independent. The input ring uses
  level-based slip (discard oldest above the high watermark, zero-fill on
  underrun), counted in telemetry. This is slip compensation, **not**
  asynchronous resampling, and `IAudioClock` is not used.
- **Latency:** `getLatencies` reports device stream latency + device buffer +
  transport cushion + Opus lookahead/framing when the codec is active.
  Latencies are only meaningful after `createBuffers` (devices open there).
- **Codec:** `%LOCALAPPDATA%\CrystalASIOCodec\config.json` (`opus_enabled`,
  `opus_frame_ms`). If Opus is requested but libopus is not built in, the driver
  says so in `getErrorMessage` and runs passthrough; it never fakes compression.
- **Lifecycle:** buffers and devices are created in `createBuffers`, host
  callbacks start in `start`, and `stop`/`disposeBuffers` wait for an in-flight
  callback and join the WASAPI threads before freeing anything.

## Known limits

- Shared mode only (`wasapi_exclusive` in config is not honoured yet).
- Default endpoints only; no device picker or control panel.
- If the Windows engine period is larger than the ASIO buffer, the host sees
  callbacks in bursts of `period / asio_buffer` back-to-back (the low-latency
  IAudioClient3 path avoids this where the driver supports it).
- Opus is applied on the input path only; output is passthrough.
- Fixed 2 in / 2 out, float32 host format.
- `outputReady()` is accepted but outputs are consumed right after the host
  callback returns.

## Build on Windows

x64 Visual Studio Developer PowerShell, ASIO SDK downloaded and licensed:

```powershell
cmake -S . -B build -A x64 -DENABLE_ASIO=ON -DASIO_SDK_ROOT="C:/SDK/ASIOSDK2.3" -DBUILD_TESTS=ON
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

Opus: add `-DCRYSTAL_ENABLE_OPUS=ON` (needs pkg-config + libopus).
Register only from an elevated terminal after review, calling `DllRegisterServer`
from a small signed installer/helper.

## Licensing

Crystal source is MIT. The Steinberg ASIO SDK is separately licensed (proprietary
or GPLv3 per its license text). Choose and document a compatible path before
distributing a combined binary.
