# Crystal Codec - Newton for macOS

**Crystal Codec - Newton** | Crystal City | Developed by Lewis J. Seals Jr. (Therealla) - ljrseals-dev

## Why not ASIO on a Mac

ASIO is a Windows driver model. macOS audio is Core Audio, whose native
low-latency driver path is an **AudioServerPlugIn** (a `.driver` bundle loaded
by `coreaudiod`). Every Mac DAW already talks to it directly, so no ASIO layer
is needed or useful.

## Provenance

`src/macos/crystal_hal_plugin.cpp` uses only Apple's public AudioServerPlugIn
API and this project's own portable core (`crystal::Transport`). It contains no
Steinberg code and needs no Steinberg SDK. (The Windows ASIO driver still
compiles against Steinberg's headers, so it is not clean-room in that sense;
have a lawyer review any clean-room claim before you make it publicly.)

## Quality design

- float32 interleaved stereo, the same format virtual and physical: no internal
  format conversion, no resampling, no dither, no limiter.
- 44.1 / 48 / 88.2 / 96 / 176.4 / 192 kHz.
- Default path is bit-exact passthrough (verified by a portable test that
  compares float bit patterns end to end through the transport).
- Opus is lossy by nature. It is compile-time opt-in
  (`-DCRYSTAL_MAC_CODEC_OPUS=ON`), never silently enabled, and is not a quality
  upgrade; use it only when bandwidth or codec behaviour is the point.

## What it is

A virtual device "Crystal Codec - Newton" with an output stream and an input
stream. Audio apps play into the output; the transport (worker, optional codec)
delivers it to the input after a one-buffer cushion. It does not route to
physical hardware by itself. Combine it with a real interface via an Aggregate
Device or Multi-Output Device in Audio MIDI Setup, or add a small helper app.

## Build and install (on a Mac)

```sh
cmake -S . -B build -DBUILD_MACOS_DRIVER=ON -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
cmake --build build --config Release
cd build && ../scripts/install_macos.sh CrystalCodec.driver
```

`install_macos.sh` ad-hoc signs (set `CODESIGN_IDENTITY` for a real identity),
copies to `/Library/Audio/Plug-Ins/HAL`, and restarts `coreaudiod`. macOS 11+
is required (C++20 `std::atomic::wait`). A distributable build needs a
Developer ID signature and notarization.

## Status

NOT compiled or run: this was written on Linux with no Apple SDK. The portable
transport it relies on is tested (ASan/UBSan/TSan clean). Expect first-build
fixes in the Core Audio glue. Unverified: device appears in Sound settings,
DAW I/O, zero-timestamp clock behaviour under load, sample-rate changes,
loopback alignment. Known limits: fixed stereo, 512-frame transport sizing, no
hardware routing, no control UI.
