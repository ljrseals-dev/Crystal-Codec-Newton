# Release gates — Crystal Codec - Newton

Legend: [x] implemented and verified here, [~] implemented, unverified on Windows, [ ] open.

- [ ] Build `CrystalAsioCodec.dll` with MSVC x64 against the selected ASIO SDK version.
- [ ] Resolve and document the SDK license path for the distribution model.
- [~] Event-driven WASAPI capture and render, COM init/uninit per thread, cleanup.
- [~] Capture -> input ring -> worker -> codec -> ASIO input buffers.
- [~] Host output buffers -> output ring -> WASAPI render.
- [~] Synthetic timer replaced by WASAPI render-event scheduling (timer kept only as outage fallback).
- [~] Format conversion from actual `WAVEFORMATEXTENSIBLE` subformat (PCM16/24/32, float).
- [~] Disconnect/reconnect, MMCSS, shutdown wake events. (`IAudioClock` not used; drift = level-based slip, [x] logic tested on Linux.)
- [x] Double-buffer addresses distinct per channel and index (allocated in `createBuffers`).
- [~] Reported latency includes device latency, ring cushion, codec lookahead/framing.
- [x] Portable tests pass on GCC (ASan/UBSan/TSan clean); [ ] MSVC/Clang.
- [ ] Validate with a real DAW and physical audio interface.
- [ ] 24-hour stability and rapid start/stop/disconnect tests.
